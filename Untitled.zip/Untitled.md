```python
from requests import Request, Session
from requests.exceptions import ConnectionError, Timeout, TooManyRedirects
import json

url = 'https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest'
parameters = {
  'start':'1',
  'limit':'15',
  'convert':'USD'
}
headers = {
  'Accepts': 'application/json',
  'X-CMC_PRO_API_KEY': '26712588-8c65-4036-ab81-a6431f3be824',
}

session = Session()
session.headers.update(headers)

try:
  response = session.get(url, params=parameters)
  data = json.loads(response.text)
  print(data)
except (ConnectionError, Timeout, TooManyRedirects) as e:
  print(e)
```

    {'status': {'timestamp': '2024-07-17T11:56:20.553Z', 'error_code': 0, 'error_message': None, 'elapsed': 31, 'credit_count': 1, 'notice': None, 'total_count': 9987}, 'data': [{'id': 1, 'name': 'Bitcoin', 'symbol': 'BTC', 'slug': 'bitcoin', 'num_market_pairs': 11605, 'date_added': '2010-07-13T00:00:00.000Z', 'tags': ['mineable', 'pow', 'sha-256', 'store-of-value', 'state-channel', 'coinbase-ventures-portfolio', 'three-arrows-capital-portfolio', 'polychain-capital-portfolio', 'binance-labs-portfolio', 'blockchain-capital-portfolio', 'boostvc-portfolio', 'cms-holdings-portfolio', 'dcg-portfolio', 'dragonfly-capital-portfolio', 'electric-capital-portfolio', 'fabric-ventures-portfolio', 'framework-ventures-portfolio', 'galaxy-digital-portfolio', 'huobi-capital-portfolio', 'alameda-research-portfolio', 'a16z-portfolio', '1confirmation-portfolio', 'winklevoss-capital-portfolio', 'usv-portfolio', 'placeholder-ventures-portfolio', 'pantera-capital-portfolio', 'multicoin-capital-portfolio', 'paradigm-portfolio', 'bitcoin-ecosystem', 'ftx-bankruptcy-estate'], 'max_supply': 21000000, 'circulating_supply': 19726856, 'total_supply': 19726856, 'infinite_supply': False, 'platform': None, 'cmc_rank': 1, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:55:00.000Z', 'quote': {'USD': {'price': 64723.610574092396, 'volume_24h': 37995372737.4273, 'volume_change_24h': -5.0121, 'percent_change_1h': -0.62571725, 'percent_change_24h': 1.56736097, 'percent_change_7d': 10.62718281, 'percent_change_30d': -1.58851937, 'percent_change_60d': -3.68418948, 'percent_change_90d': 3.14370177, 'market_cap': 1276793345595.198, 'market_cap_dominance': 53.7098, 'fully_diluted_market_cap': 1359195822055.94, 'tvl': None, 'last_updated': '2024-07-17T11:55:00.000Z'}}}, {'id': 1027, 'name': 'Ethereum', 'symbol': 'ETH', 'slug': 'ethereum', 'num_market_pairs': 9144, 'date_added': '2015-08-07T00:00:00.000Z', 'tags': ['pos', 'smart-contracts', 'ethereum-ecosystem', 'coinbase-ventures-portfolio', 'three-arrows-capital-portfolio', 'polychain-capital-portfolio', 'binance-labs-portfolio', 'blockchain-capital-portfolio', 'boostvc-portfolio', 'cms-holdings-portfolio', 'dcg-portfolio', 'dragonfly-capital-portfolio', 'electric-capital-portfolio', 'fabric-ventures-portfolio', 'framework-ventures-portfolio', 'hashkey-capital-portfolio', 'kenetic-capital-portfolio', 'huobi-capital-portfolio', 'alameda-research-portfolio', 'a16z-portfolio', '1confirmation-portfolio', 'winklevoss-capital-portfolio', 'usv-portfolio', 'placeholder-ventures-portfolio', 'pantera-capital-portfolio', 'multicoin-capital-portfolio', 'paradigm-portfolio', 'injective-ecosystem', 'layer-1', 'ftx-bankruptcy-estate'], 'max_supply': None, 'circulating_supply': 120221218.02997445, 'total_supply': 120221218.02997445, 'infinite_supply': True, 'platform': None, 'cmc_rank': 2, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 3449.458308947094, 'volume_24h': 19151313483.847897, 'volume_change_24h': -3.3076, 'percent_change_1h': -0.91889164, 'percent_change_24h': 0.92088662, 'percent_change_7d': 11.23546332, 'percent_change_30d': -2.01434592, 'percent_change_60d': 9.88935742, 'percent_change_90d': 13.04704208, 'market_cap': 414698079445.23553, 'market_cap_dominance': 17.4446, 'fully_diluted_market_cap': 414698079445.24, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 825, 'name': 'Tether USDt', 'symbol': 'USDT', 'slug': 'tether', 'num_market_pairs': 91758, 'date_added': '2015-02-25T00:00:00.000Z', 'tags': ['stablecoin', 'asset-backed-stablecoin', 'avalanche-ecosystem', 'solana-ecosystem', 'arbitrum-ecosytem', 'moonriver-ecosystem', 'injective-ecosystem', 'bnb-chain', 'usd-stablecoin', 'optimism-ecosystem', 'fiat-stablecoin'], 'max_supply': None, 'circulating_supply': 113224555138.6441, 'total_supply': 117072162581.7876, 'platform': {'id': 1027, 'name': 'Ethereum', 'symbol': 'ETH', 'slug': 'ethereum', 'token_address': '0xdac17f958d2ee523a2206206994597c13d831ec7'}, 'infinite_supply': True, 'cmc_rank': 3, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 1.000313332019777, 'volume_24h': 70168361530.56512, 'volume_change_24h': -4.6989, 'percent_change_1h': 0.00943872, 'percent_change_24h': -0.01274308, 'percent_change_7d': 0.03935349, 'percent_change_30d': 0.1015451, 'percent_change_60d': -0.004213, 'percent_change_90d': -0.04923533, 'market_cap': 113260032017.19405, 'market_cap_dominance': 4.7644, 'fully_diluted_market_cap': 117108845038.95, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 1839, 'name': 'BNB', 'symbol': 'BNB', 'slug': 'bnb', 'num_market_pairs': 2192, 'date_added': '2017-07-25T00:00:00.000Z', 'tags': ['marketplace', 'centralized-exchange', 'payments', 'smart-contracts', 'alameda-research-portfolio', 'multicoin-capital-portfolio', 'bnb-chain', 'layer-1', 'sec-security-token', 'alleged-sec-securities', 'celsius-bankruptcy-estate'], 'max_supply': None, 'circulating_supply': 147582069.6774636, 'total_supply': 147582069.6774636, 'infinite_supply': False, 'platform': None, 'cmc_rank': 4, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 575.6221614687437, 'volume_24h': 1876534604.8572059, 'volume_change_24h': -10.8947, 'percent_change_1h': -0.74976601, 'percent_change_24h': 0.83081616, 'percent_change_7d': 9.05143861, 'percent_change_30d': -3.7831224, 'percent_change_60d': -0.78191534, 'percent_change_90d': 5.11585154, 'market_cap': 84951509941.77232, 'market_cap_dominance': 3.5736, 'fully_diluted_market_cap': 84951509941.77, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 5426, 'name': 'Solana', 'symbol': 'SOL', 'slug': 'solana', 'num_market_pairs': 705, 'date_added': '2020-04-10T00:00:00.000Z', 'tags': ['pos', 'platform', 'solana-ecosystem', 'cms-holdings-portfolio', 'kenetic-capital-portfolio', 'alameda-research-portfolio', 'multicoin-capital-portfolio', 'okx-ventures-portfolio', 'layer-1', 'ftx-bankruptcy-estate', 'sec-security-token', 'alleged-sec-securities', 'cmc-crypto-awards-2024'], 'max_supply': None, 'circulating_supply': 464175526.7804486, 'total_supply': 580287041.1873215, 'infinite_supply': True, 'platform': None, 'cmc_rank': 5, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 160.91142372989643, 'volume_24h': 2654514490.789488, 'volume_change_24h': -6.5061, 'percent_change_1h': -1.0680309, 'percent_change_24h': 2.37398939, 'percent_change_7d': 12.40712552, 'percent_change_30d': 12.02192461, 'percent_change_60d': -7.85116573, 'percent_change_90d': 18.12620142, 'market_cap': 74691144874.81665, 'market_cap_dominance': 3.1431, 'fully_diluted_market_cap': 93374813969.46, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 52, 'name': 'XRP', 'symbol': 'XRP', 'slug': 'xrp', 'num_market_pairs': 1354, 'date_added': '2013-08-04T00:00:00.000Z', 'tags': ['medium-of-exchange', 'enterprise-solutions', 'arrington-xrp-capital-portfolio', 'galaxy-digital-portfolio', 'a16z-portfolio', 'pantera-capital-portfolio', 'ftx-bankruptcy-estate'], 'max_supply': 100000000000, 'circulating_supply': 55805339473, 'total_supply': 99987452475, 'infinite_supply': False, 'platform': None, 'cmc_rank': 6, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:55:00.000Z', 'quote': {'USD': {'price': 0.6127071820723412, 'volume_24h': 3703927536.2948728, 'volume_change_24h': 58.5376, 'percent_change_1h': -0.24693669, 'percent_change_24h': 12.04140479, 'percent_change_7d': 38.92497025, 'percent_change_30d': 23.12027412, 'percent_change_60d': 16.89664202, 'percent_change_90d': 23.36795234, 'market_cap': 34192332293.09222, 'market_cap_dominance': 1.4383, 'fully_diluted_market_cap': 61270718207.23, 'tvl': None, 'last_updated': '2024-07-17T11:55:00.000Z'}}}, {'id': 3408, 'name': 'USDC', 'symbol': 'USDC', 'slug': 'usd-coin', 'num_market_pairs': 21018, 'date_added': '2018-10-08T00:00:00.000Z', 'tags': ['medium-of-exchange', 'stablecoin', 'asset-backed-stablecoin', 'coinbase-ventures-portfolio', 'hedera-hashgraph-ecosystem', 'fantom-ecosystem', 'arbitrum-ecosytem', 'moonriver-ecosystem', 'bnb-chain', 'usd-stablecoin', 'optimism-ecosystem', 'fiat-stablecoin'], 'max_supply': None, 'circulating_supply': 33922858555.547703, 'total_supply': 33922858555.547703, 'platform': {'id': 1027, 'name': 'Ethereum', 'symbol': 'ETH', 'slug': 'ethereum', 'token_address': '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'}, 'infinite_supply': False, 'cmc_rank': 7, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 1.0000610198945894, 'volume_24h': 7278092328.194868, 'volume_change_24h': -6.6251, 'percent_change_1h': 0.01081903, 'percent_change_24h': -0.00264087, 'percent_change_7d': 0.00472465, 'percent_change_30d': 0.00549262, 'percent_change_60d': -0.00216487, 'percent_change_90d': -0.02574653, 'market_cap': 33924928524.800934, 'market_cap_dominance': 1.4271, 'fully_diluted_market_cap': 33924928524.8, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 11419, 'name': 'Toncoin', 'symbol': 'TON', 'slug': 'toncoin', 'num_market_pairs': 462, 'date_added': '2021-08-26T13:40:22.000Z', 'tags': ['pos', 'layer-1', 'ftx-bankruptcy-estate', 'dwf-labs-portfolio', 'toncoin-ecosystem'], 'max_supply': None, 'circulating_supply': 2512029661.5461416, 'total_supply': 5109102576.017184, 'infinite_supply': True, 'platform': None, 'cmc_rank': 8, 'self_reported_circulating_supply': 3414166606, 'self_reported_market_cap': 24650985931.97799, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 7.220205917501727, 'volume_24h': 253931271.30099422, 'volume_change_24h': -11.339, 'percent_change_1h': -0.68928216, 'percent_change_24h': -2.33508124, 'percent_change_7d': -1.57426351, 'percent_change_30d': -7.15873422, 'percent_change_60d': 10.91285127, 'percent_change_90d': 17.52034532, 'market_cap': 18137371427.235313, 'market_cap_dominance': 0.763, 'fully_diluted_market_cap': 36888772652.48, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 74, 'name': 'Dogecoin', 'symbol': 'DOGE', 'slug': 'dogecoin', 'num_market_pairs': 1025, 'date_added': '2013-12-15T00:00:00.000Z', 'tags': ['mineable', 'pow', 'scrypt', 'medium-of-exchange', 'memes', 'payments', 'doggone-doggerel', 'bnb-chain', 'ftx-bankruptcy-estate'], 'max_supply': None, 'circulating_supply': 145151856383.70523, 'total_supply': 145151856383.70523, 'infinite_supply': True, 'platform': None, 'cmc_rank': 9, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:55:00.000Z', 'quote': {'USD': {'price': 0.124173589837295, 'volume_24h': 812603351.3701594, 'volume_change_24h': -22.589, 'percent_change_1h': -0.97964354, 'percent_change_24h': 1.64740313, 'percent_change_7d': 13.41038645, 'percent_change_30d': -7.50461585, 'percent_change_60d': -20.45761899, 'percent_change_90d': -16.73450328, 'market_cap': 18024027078.712162, 'market_cap_dominance': 0.7582, 'fully_diluted_market_cap': 18024027078.71, 'tvl': None, 'last_updated': '2024-07-17T11:55:00.000Z'}}}, {'id': 2010, 'name': 'Cardano', 'symbol': 'ADA', 'slug': 'cardano', 'num_market_pairs': 1213, 'date_added': '2017-10-01T00:00:00.000Z', 'tags': ['dpos', 'pos', 'platform', 'research', 'smart-contracts', 'staking', 'cardano-ecosystem', 'cardano', 'layer-1', 'sec-security-token', 'alleged-sec-securities'], 'max_supply': 45000000000, 'circulating_supply': 35886483198.554, 'total_supply': 37048613783.371, 'infinite_supply': False, 'platform': None, 'cmc_rank': 10, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 0.44582743135733394, 'volume_24h': 424155221.50482637, 'volume_change_24h': -17.4438, 'percent_change_1h': -0.52428042, 'percent_change_24h': 3.23045759, 'percent_change_7d': 16.42994373, 'percent_change_30d': 10.22147042, 'percent_change_60d': -7.98226114, 'percent_change_90d': -1.28999942, 'market_cap': 15999178624.859451, 'market_cap_dominance': 0.6733, 'fully_diluted_market_cap': 20062234411.08, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 1958, 'name': 'TRON', 'symbol': 'TRX', 'slug': 'tron', 'num_market_pairs': 1001, 'date_added': '2017-09-13T00:00:00.000Z', 'tags': ['media', 'payments', 'tron-ecosystem', 'layer-1', 'dwf-labs-portfolio', 'sec-security-token', 'alleged-sec-securities'], 'max_supply': None, 'circulating_supply': 87107723240.61296, 'total_supply': 87107760425.04483, 'infinite_supply': True, 'platform': None, 'cmc_rank': 11, 'self_reported_circulating_supply': 71659659264, 'self_reported_market_cap': 9649984666.079927, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 0.13466411597812097, 'volume_24h': 320496928.19484925, 'volume_change_24h': -27.3278, 'percent_change_1h': 0.03134974, 'percent_change_24h': 0.38898625, 'percent_change_7d': 3.52567298, 'percent_change_30d': 15.33851065, 'percent_change_60d': 8.8553765, 'percent_change_90d': 22.78626659, 'market_cap': 11730284545.063967, 'market_cap_dominance': 0.4934, 'fully_diluted_market_cap': 11730289552.47, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 5994, 'name': 'Shiba Inu', 'symbol': 'SHIB', 'slug': 'shiba-inu', 'num_market_pairs': 846, 'date_added': '2020-08-01T00:00:00.000Z', 'tags': ['memes', 'ethereum-ecosystem', 'doggone-doggerel'], 'max_supply': None, 'circulating_supply': 589270743113993.8, 'total_supply': 589519212467867.4, 'platform': {'id': 1027, 'name': 'Ethereum', 'symbol': 'ETH', 'slug': 'ethereum', 'token_address': '0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce'}, 'infinite_supply': False, 'cmc_rank': 12, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 1.9328357324870212e-05, 'volume_24h': 484313748.3462978, 'volume_change_24h': -32.0363, 'percent_change_1h': 0.13788412, 'percent_change_24h': 0.16280342, 'percent_change_7d': 15.58935383, 'percent_change_30d': -3.15363042, 'percent_change_60d': -22.93485979, 'percent_change_90d': -13.62609592, 'market_cap': 11389635483.999075, 'market_cap_dominance': 0.4791, 'fully_diluted_market_cap': 11394437988.46, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 5805, 'name': 'Avalanche', 'symbol': 'AVAX', 'slug': 'avalanche', 'num_market_pairs': 752, 'date_added': '2020-07-13T00:00:00.000Z', 'tags': ['defi', 'smart-contracts', 'three-arrows-capital-portfolio', 'polychain-capital-portfolio', 'avalanche-ecosystem', 'cms-holdings-portfolio', 'dragonfly-capital-portfolio', 'moonriver-ecosystem', 'injective-ecosystem', 'real-world-assets', 'layer-1'], 'max_supply': 715748719, 'circulating_supply': 394688210.3669582, 'total_supply': 444034580.3669582, 'infinite_supply': False, 'platform': None, 'cmc_rank': 13, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 28.17394823366332, 'volume_24h': 445378643.2369945, 'volume_change_24h': 8.1925, 'percent_change_1h': -1.40467829, 'percent_change_24h': 3.50296093, 'percent_change_7d': 4.59962839, 'percent_change_30d': -1.55128421, 'percent_change_60d': -24.81821072, 'percent_change_90d': -19.73123583, 'market_cap': 11119925207.315899, 'market_cap_dominance': 0.4678, 'fully_diluted_market_cap': 20165467357.42, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 6636, 'name': 'Polkadot', 'symbol': 'DOT', 'slug': 'polkadot-new', 'num_market_pairs': 793, 'date_added': '2020-08-19T00:00:00.000Z', 'tags': ['substrate', 'polkadot', 'binance-chain', 'polkadot-ecosystem', 'three-arrows-capital-portfolio', 'polychain-capital-portfolio', 'arrington-xrp-capital-portfolio', 'blockchain-capital-portfolio', 'boostvc-portfolio', 'cms-holdings-portfolio', 'coinfund-portfolio', 'fabric-ventures-portfolio', 'fenbushi-capital-portfolio', 'hashkey-capital-portfolio', 'kenetic-capital-portfolio', '1confirmation-portfolio', 'placeholder-ventures-portfolio', 'pantera-capital-portfolio', 'exnetwork-capital-portfolio', 'web3', 'spartan-group', 'injective-ecosystem', 'bnb-chain', 'layer-1'], 'max_supply': None, 'circulating_supply': 1437953431.368154, 'total_supply': 1437953431.368154, 'infinite_supply': True, 'platform': None, 'cmc_rank': 14, 'self_reported_circulating_supply': 1469841795.4022434, 'self_reported_market_cap': 9470358969.344936, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 6.443114489578952, 'volume_24h': 203767585.0865228, 'volume_change_24h': -7.0402, 'percent_change_1h': -0.61932852, 'percent_change_24h': 2.63259181, 'percent_change_7d': 5.23403037, 'percent_change_30d': 4.02892556, 'percent_change_60d': -10.50496699, 'percent_change_90d': -3.92833578, 'market_cap': 9264898588.987926, 'market_cap_dominance': 0.3898, 'fully_diluted_market_cap': 9264898588.99, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 1975, 'name': 'Chainlink', 'symbol': 'LINK', 'slug': 'chainlink', 'num_market_pairs': 1817, 'date_added': '2017-09-20T00:00:00.000Z', 'tags': ['platform', 'defi', 'oracles', 'smart-contracts', 'substrate', 'polkadot', 'avalanche-ecosystem', 'solana-ecosystem', 'framework-ventures-portfolio', 'polygon-ecosystem', 'fantom-ecosystem', 'cardano-ecosystem', 'web3', 'near-protocol-ecosystem', 'arbitrum-ecosytem', 'cardano', 'injective-ecosystem', 'optimism-ecosystem', 'real-world-assets', 'celsius-bankruptcy-estate'], 'max_supply': None, 'circulating_supply': 608099970.4527867, 'total_supply': 1000000000, 'platform': {'id': 1027, 'name': 'Ethereum', 'symbol': 'ETH', 'slug': 'ethereum', 'token_address': '0x514910771af9ca656af840dff83e8264ecf986ca'}, 'infinite_supply': False, 'cmc_rank': 15, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 14.334612082769768, 'volume_24h': 346644916.9890132, 'volume_change_24h': -9.6771, 'percent_change_1h': -0.65909468, 'percent_change_24h': 1.78882201, 'percent_change_7d': 11.01146091, 'percent_change_30d': -0.03753733, 'percent_change_60d': -11.3902048, 'percent_change_90d': 7.21066877, 'market_cap': 8716877183.984455, 'market_cap_dominance': 0.3667, 'fully_diluted_market_cap': 14334612082.77, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}]}
    


```python
type(data)
```




    dict




```python
import pandas as pd 
```


```python
# this make data like dataframe
df=pd.json_normalize(data['data'])
df['timestamp']=pd.to_datetime('now')
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>name</th>
      <th>symbol</th>
      <th>slug</th>
      <th>num_market_pairs</th>
      <th>date_added</th>
      <th>tags</th>
      <th>max_supply</th>
      <th>circulating_supply</th>
      <th>total_supply</th>
      <th>...</th>
      <th>quote.USD.market_cap_dominance</th>
      <th>quote.USD.fully_diluted_market_cap</th>
      <th>quote.USD.tvl</th>
      <th>quote.USD.last_updated</th>
      <th>platform.id</th>
      <th>platform.name</th>
      <th>platform.symbol</th>
      <th>platform.slug</th>
      <th>platform.token_address</th>
      <th>timestamp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Bitcoin</td>
      <td>BTC</td>
      <td>bitcoin</td>
      <td>11605</td>
      <td>2010-07-13T00:00:00.000Z</td>
      <td>[mineable, pow, sha-256, store-of-value, state...</td>
      <td>2.100000e+07</td>
      <td>1.972686e+07</td>
      <td>1.972686e+07</td>
      <td>...</td>
      <td>53.7098</td>
      <td>1.359196e+12</td>
      <td>None</td>
      <td>2024-07-17T11:55:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1027</td>
      <td>Ethereum</td>
      <td>ETH</td>
      <td>ethereum</td>
      <td>9144</td>
      <td>2015-08-07T00:00:00.000Z</td>
      <td>[pos, smart-contracts, ethereum-ecosystem, coi...</td>
      <td>NaN</td>
      <td>1.202212e+08</td>
      <td>1.202212e+08</td>
      <td>...</td>
      <td>17.4446</td>
      <td>4.146981e+11</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>2</th>
      <td>825</td>
      <td>Tether USDt</td>
      <td>USDT</td>
      <td>tether</td>
      <td>91758</td>
      <td>2015-02-25T00:00:00.000Z</td>
      <td>[stablecoin, asset-backed-stablecoin, avalanch...</td>
      <td>NaN</td>
      <td>1.132246e+11</td>
      <td>1.170722e+11</td>
      <td>...</td>
      <td>4.7644</td>
      <td>1.171088e+11</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>1027.0</td>
      <td>Ethereum</td>
      <td>ETH</td>
      <td>ethereum</td>
      <td>0xdac17f958d2ee523a2206206994597c13d831ec7</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1839</td>
      <td>BNB</td>
      <td>BNB</td>
      <td>bnb</td>
      <td>2192</td>
      <td>2017-07-25T00:00:00.000Z</td>
      <td>[marketplace, centralized-exchange, payments, ...</td>
      <td>NaN</td>
      <td>1.475821e+08</td>
      <td>1.475821e+08</td>
      <td>...</td>
      <td>3.5736</td>
      <td>8.495151e+10</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5426</td>
      <td>Solana</td>
      <td>SOL</td>
      <td>solana</td>
      <td>705</td>
      <td>2020-04-10T00:00:00.000Z</td>
      <td>[pos, platform, solana-ecosystem, cms-holdings...</td>
      <td>NaN</td>
      <td>4.641755e+08</td>
      <td>5.802870e+08</td>
      <td>...</td>
      <td>3.1431</td>
      <td>9.337481e+10</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>5</th>
      <td>52</td>
      <td>XRP</td>
      <td>XRP</td>
      <td>xrp</td>
      <td>1354</td>
      <td>2013-08-04T00:00:00.000Z</td>
      <td>[medium-of-exchange, enterprise-solutions, arr...</td>
      <td>1.000000e+11</td>
      <td>5.580534e+10</td>
      <td>9.998745e+10</td>
      <td>...</td>
      <td>1.4383</td>
      <td>6.127072e+10</td>
      <td>None</td>
      <td>2024-07-17T11:55:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>6</th>
      <td>3408</td>
      <td>USDC</td>
      <td>USDC</td>
      <td>usd-coin</td>
      <td>21018</td>
      <td>2018-10-08T00:00:00.000Z</td>
      <td>[medium-of-exchange, stablecoin, asset-backed-...</td>
      <td>NaN</td>
      <td>3.392286e+10</td>
      <td>3.392286e+10</td>
      <td>...</td>
      <td>1.4271</td>
      <td>3.392493e+10</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>1027.0</td>
      <td>Ethereum</td>
      <td>ETH</td>
      <td>ethereum</td>
      <td>0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>7</th>
      <td>11419</td>
      <td>Toncoin</td>
      <td>TON</td>
      <td>toncoin</td>
      <td>462</td>
      <td>2021-08-26T13:40:22.000Z</td>
      <td>[pos, layer-1, ftx-bankruptcy-estate, dwf-labs...</td>
      <td>NaN</td>
      <td>2.512030e+09</td>
      <td>5.109103e+09</td>
      <td>...</td>
      <td>0.7630</td>
      <td>3.688877e+10</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>8</th>
      <td>74</td>
      <td>Dogecoin</td>
      <td>DOGE</td>
      <td>dogecoin</td>
      <td>1025</td>
      <td>2013-12-15T00:00:00.000Z</td>
      <td>[mineable, pow, scrypt, medium-of-exchange, me...</td>
      <td>NaN</td>
      <td>1.451519e+11</td>
      <td>1.451519e+11</td>
      <td>...</td>
      <td>0.7582</td>
      <td>1.802403e+10</td>
      <td>None</td>
      <td>2024-07-17T11:55:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2010</td>
      <td>Cardano</td>
      <td>ADA</td>
      <td>cardano</td>
      <td>1213</td>
      <td>2017-10-01T00:00:00.000Z</td>
      <td>[dpos, pos, platform, research, smart-contract...</td>
      <td>4.500000e+10</td>
      <td>3.588648e+10</td>
      <td>3.704861e+10</td>
      <td>...</td>
      <td>0.6733</td>
      <td>2.006223e+10</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1958</td>
      <td>TRON</td>
      <td>TRX</td>
      <td>tron</td>
      <td>1001</td>
      <td>2017-09-13T00:00:00.000Z</td>
      <td>[media, payments, tron-ecosystem, layer-1, dwf...</td>
      <td>NaN</td>
      <td>8.710772e+10</td>
      <td>8.710776e+10</td>
      <td>...</td>
      <td>0.4934</td>
      <td>1.173029e+10</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>11</th>
      <td>5994</td>
      <td>Shiba Inu</td>
      <td>SHIB</td>
      <td>shiba-inu</td>
      <td>846</td>
      <td>2020-08-01T00:00:00.000Z</td>
      <td>[memes, ethereum-ecosystem, doggone-doggerel]</td>
      <td>NaN</td>
      <td>5.892707e+14</td>
      <td>5.895192e+14</td>
      <td>...</td>
      <td>0.4791</td>
      <td>1.139444e+10</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>1027.0</td>
      <td>Ethereum</td>
      <td>ETH</td>
      <td>ethereum</td>
      <td>0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>12</th>
      <td>5805</td>
      <td>Avalanche</td>
      <td>AVAX</td>
      <td>avalanche</td>
      <td>752</td>
      <td>2020-07-13T00:00:00.000Z</td>
      <td>[defi, smart-contracts, three-arrows-capital-p...</td>
      <td>7.157487e+08</td>
      <td>3.946882e+08</td>
      <td>4.440346e+08</td>
      <td>...</td>
      <td>0.4678</td>
      <td>2.016547e+10</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>13</th>
      <td>6636</td>
      <td>Polkadot</td>
      <td>DOT</td>
      <td>polkadot-new</td>
      <td>793</td>
      <td>2020-08-19T00:00:00.000Z</td>
      <td>[substrate, polkadot, binance-chain, polkadot-...</td>
      <td>NaN</td>
      <td>1.437953e+09</td>
      <td>1.437953e+09</td>
      <td>...</td>
      <td>0.3898</td>
      <td>9.264899e+09</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1975</td>
      <td>Chainlink</td>
      <td>LINK</td>
      <td>chainlink</td>
      <td>1817</td>
      <td>2017-09-20T00:00:00.000Z</td>
      <td>[platform, defi, oracles, smart-contracts, sub...</td>
      <td>NaN</td>
      <td>6.081000e+08</td>
      <td>1.000000e+09</td>
      <td>...</td>
      <td>0.3667</td>
      <td>1.433461e+10</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>1027.0</td>
      <td>Ethereum</td>
      <td>ETH</td>
      <td>ethereum</td>
      <td>0x514910771af9ca656af840dff83e8264ecf986ca</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
  </tbody>
</table>
<p>15 rows × 37 columns</p>
</div>




```python
def api_runner():
 url = 'https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest'
 parameters = {
  'start':'1',
  'limit':'15',
  'convert':'USD'
 }
 headers = {
  'Accepts': 'application/json',
  'X-CMC_PRO_API_KEY': '26712588-8c65-4036-ab81-a6431f3be824',
 }

 session = Session()
 session.headers.update(headers)

 try:
  response = session.get(url, params=parameters)
  data = json.loads(response.text)
  print(data)
 except (ConnectionError, Timeout, TooManyRedirects) as e:
  print(e)

    
  df2 =pd.json_normalize(data['data'])  
  df2['timestamp'] = pd.to_datetime('now')
  df=df.append(df2)
     
  
  
  
```


```python
 
  df.to_csv('API.csv')
```


```python
import os 
from time import time
from time import sleep

for i in range(1): 
    api_runner()
    print('api Runner completed')
    sleep(60) # sleep for 1 minutes
exit()

```

    {'status': {'timestamp': '2024-07-17T11:56:46.825Z', 'error_code': 0, 'error_message': None, 'elapsed': 23, 'credit_count': 1, 'notice': None, 'total_count': 9987}, 'data': [{'id': 1, 'name': 'Bitcoin', 'symbol': 'BTC', 'slug': 'bitcoin', 'num_market_pairs': 11605, 'date_added': '2010-07-13T00:00:00.000Z', 'tags': ['mineable', 'pow', 'sha-256', 'store-of-value', 'state-channel', 'coinbase-ventures-portfolio', 'three-arrows-capital-portfolio', 'polychain-capital-portfolio', 'binance-labs-portfolio', 'blockchain-capital-portfolio', 'boostvc-portfolio', 'cms-holdings-portfolio', 'dcg-portfolio', 'dragonfly-capital-portfolio', 'electric-capital-portfolio', 'fabric-ventures-portfolio', 'framework-ventures-portfolio', 'galaxy-digital-portfolio', 'huobi-capital-portfolio', 'alameda-research-portfolio', 'a16z-portfolio', '1confirmation-portfolio', 'winklevoss-capital-portfolio', 'usv-portfolio', 'placeholder-ventures-portfolio', 'pantera-capital-portfolio', 'multicoin-capital-portfolio', 'paradigm-portfolio', 'bitcoin-ecosystem', 'ftx-bankruptcy-estate'], 'max_supply': 21000000, 'circulating_supply': 19726856, 'total_supply': 19726856, 'infinite_supply': False, 'platform': None, 'cmc_rank': 1, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:55:00.000Z', 'quote': {'USD': {'price': 64723.610574092396, 'volume_24h': 37995372737.4273, 'volume_change_24h': -5.0121, 'percent_change_1h': -0.62571725, 'percent_change_24h': 1.56736097, 'percent_change_7d': 10.62718281, 'percent_change_30d': -1.58851937, 'percent_change_60d': -3.68418948, 'percent_change_90d': 3.14370177, 'market_cap': 1276793345595.198, 'market_cap_dominance': 53.7098, 'fully_diluted_market_cap': 1359195822055.94, 'tvl': None, 'last_updated': '2024-07-17T11:55:00.000Z'}}}, {'id': 1027, 'name': 'Ethereum', 'symbol': 'ETH', 'slug': 'ethereum', 'num_market_pairs': 9144, 'date_added': '2015-08-07T00:00:00.000Z', 'tags': ['pos', 'smart-contracts', 'ethereum-ecosystem', 'coinbase-ventures-portfolio', 'three-arrows-capital-portfolio', 'polychain-capital-portfolio', 'binance-labs-portfolio', 'blockchain-capital-portfolio', 'boostvc-portfolio', 'cms-holdings-portfolio', 'dcg-portfolio', 'dragonfly-capital-portfolio', 'electric-capital-portfolio', 'fabric-ventures-portfolio', 'framework-ventures-portfolio', 'hashkey-capital-portfolio', 'kenetic-capital-portfolio', 'huobi-capital-portfolio', 'alameda-research-portfolio', 'a16z-portfolio', '1confirmation-portfolio', 'winklevoss-capital-portfolio', 'usv-portfolio', 'placeholder-ventures-portfolio', 'pantera-capital-portfolio', 'multicoin-capital-portfolio', 'paradigm-portfolio', 'injective-ecosystem', 'layer-1', 'ftx-bankruptcy-estate'], 'max_supply': None, 'circulating_supply': 120221218.02997445, 'total_supply': 120221218.02997445, 'infinite_supply': True, 'platform': None, 'cmc_rank': 2, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 3449.458308947094, 'volume_24h': 19151313483.847897, 'volume_change_24h': -3.3076, 'percent_change_1h': -0.91889164, 'percent_change_24h': 0.92088662, 'percent_change_7d': 11.23546332, 'percent_change_30d': -2.01434592, 'percent_change_60d': 9.88935742, 'percent_change_90d': 13.04704208, 'market_cap': 414698079445.23553, 'market_cap_dominance': 17.4446, 'fully_diluted_market_cap': 414698079445.24, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 825, 'name': 'Tether USDt', 'symbol': 'USDT', 'slug': 'tether', 'num_market_pairs': 91758, 'date_added': '2015-02-25T00:00:00.000Z', 'tags': ['stablecoin', 'asset-backed-stablecoin', 'avalanche-ecosystem', 'solana-ecosystem', 'arbitrum-ecosytem', 'moonriver-ecosystem', 'injective-ecosystem', 'bnb-chain', 'usd-stablecoin', 'optimism-ecosystem', 'fiat-stablecoin'], 'max_supply': None, 'circulating_supply': 113224555138.6441, 'total_supply': 117072162581.7876, 'platform': {'id': 1027, 'name': 'Ethereum', 'symbol': 'ETH', 'slug': 'ethereum', 'token_address': '0xdac17f958d2ee523a2206206994597c13d831ec7'}, 'infinite_supply': True, 'cmc_rank': 3, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 1.000313332019777, 'volume_24h': 70168361530.56512, 'volume_change_24h': -4.6989, 'percent_change_1h': 0.00943872, 'percent_change_24h': -0.01274308, 'percent_change_7d': 0.03935349, 'percent_change_30d': 0.1015451, 'percent_change_60d': -0.004213, 'percent_change_90d': -0.04923533, 'market_cap': 113260032017.19405, 'market_cap_dominance': 4.7644, 'fully_diluted_market_cap': 117108845038.95, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 1839, 'name': 'BNB', 'symbol': 'BNB', 'slug': 'bnb', 'num_market_pairs': 2192, 'date_added': '2017-07-25T00:00:00.000Z', 'tags': ['marketplace', 'centralized-exchange', 'payments', 'smart-contracts', 'alameda-research-portfolio', 'multicoin-capital-portfolio', 'bnb-chain', 'layer-1', 'sec-security-token', 'alleged-sec-securities', 'celsius-bankruptcy-estate'], 'max_supply': None, 'circulating_supply': 147582069.6774636, 'total_supply': 147582069.6774636, 'infinite_supply': False, 'platform': None, 'cmc_rank': 4, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 575.6221614687437, 'volume_24h': 1876534604.8572059, 'volume_change_24h': -10.8947, 'percent_change_1h': -0.74976601, 'percent_change_24h': 0.83081616, 'percent_change_7d': 9.05143861, 'percent_change_30d': -3.7831224, 'percent_change_60d': -0.78191534, 'percent_change_90d': 5.11585154, 'market_cap': 84951509941.77232, 'market_cap_dominance': 3.5736, 'fully_diluted_market_cap': 84951509941.77, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 5426, 'name': 'Solana', 'symbol': 'SOL', 'slug': 'solana', 'num_market_pairs': 705, 'date_added': '2020-04-10T00:00:00.000Z', 'tags': ['pos', 'platform', 'solana-ecosystem', 'cms-holdings-portfolio', 'kenetic-capital-portfolio', 'alameda-research-portfolio', 'multicoin-capital-portfolio', 'okx-ventures-portfolio', 'layer-1', 'ftx-bankruptcy-estate', 'sec-security-token', 'alleged-sec-securities', 'cmc-crypto-awards-2024'], 'max_supply': None, 'circulating_supply': 464175526.7804486, 'total_supply': 580287041.1873215, 'infinite_supply': True, 'platform': None, 'cmc_rank': 5, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 160.91142372989643, 'volume_24h': 2654514490.789488, 'volume_change_24h': -6.5061, 'percent_change_1h': -1.0680309, 'percent_change_24h': 2.37398939, 'percent_change_7d': 12.40712552, 'percent_change_30d': 12.02192461, 'percent_change_60d': -7.85116573, 'percent_change_90d': 18.12620142, 'market_cap': 74691144874.81665, 'market_cap_dominance': 3.1431, 'fully_diluted_market_cap': 93374813969.46, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 52, 'name': 'XRP', 'symbol': 'XRP', 'slug': 'xrp', 'num_market_pairs': 1354, 'date_added': '2013-08-04T00:00:00.000Z', 'tags': ['medium-of-exchange', 'enterprise-solutions', 'arrington-xrp-capital-portfolio', 'galaxy-digital-portfolio', 'a16z-portfolio', 'pantera-capital-portfolio', 'ftx-bankruptcy-estate'], 'max_supply': 100000000000, 'circulating_supply': 55805339473, 'total_supply': 99987452475, 'infinite_supply': False, 'platform': None, 'cmc_rank': 6, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:55:00.000Z', 'quote': {'USD': {'price': 0.6127071820723412, 'volume_24h': 3703927536.2948728, 'volume_change_24h': 58.5376, 'percent_change_1h': -0.24693669, 'percent_change_24h': 12.04140479, 'percent_change_7d': 38.92497025, 'percent_change_30d': 23.12027412, 'percent_change_60d': 16.89664202, 'percent_change_90d': 23.36795234, 'market_cap': 34192332293.09222, 'market_cap_dominance': 1.4383, 'fully_diluted_market_cap': 61270718207.23, 'tvl': None, 'last_updated': '2024-07-17T11:55:00.000Z'}}}, {'id': 3408, 'name': 'USDC', 'symbol': 'USDC', 'slug': 'usd-coin', 'num_market_pairs': 21018, 'date_added': '2018-10-08T00:00:00.000Z', 'tags': ['medium-of-exchange', 'stablecoin', 'asset-backed-stablecoin', 'coinbase-ventures-portfolio', 'hedera-hashgraph-ecosystem', 'fantom-ecosystem', 'arbitrum-ecosytem', 'moonriver-ecosystem', 'bnb-chain', 'usd-stablecoin', 'optimism-ecosystem', 'fiat-stablecoin'], 'max_supply': None, 'circulating_supply': 33922858555.547703, 'total_supply': 33922858555.547703, 'platform': {'id': 1027, 'name': 'Ethereum', 'symbol': 'ETH', 'slug': 'ethereum', 'token_address': '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'}, 'infinite_supply': False, 'cmc_rank': 7, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 1.0000610198945894, 'volume_24h': 7278092328.194868, 'volume_change_24h': -6.6251, 'percent_change_1h': 0.01081903, 'percent_change_24h': -0.00264087, 'percent_change_7d': 0.00472465, 'percent_change_30d': 0.00549262, 'percent_change_60d': -0.00216487, 'percent_change_90d': -0.02574653, 'market_cap': 33924928524.800934, 'market_cap_dominance': 1.4271, 'fully_diluted_market_cap': 33924928524.8, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 11419, 'name': 'Toncoin', 'symbol': 'TON', 'slug': 'toncoin', 'num_market_pairs': 462, 'date_added': '2021-08-26T13:40:22.000Z', 'tags': ['pos', 'layer-1', 'ftx-bankruptcy-estate', 'dwf-labs-portfolio', 'toncoin-ecosystem'], 'max_supply': None, 'circulating_supply': 2512029661.5461416, 'total_supply': 5109102576.017184, 'infinite_supply': True, 'platform': None, 'cmc_rank': 8, 'self_reported_circulating_supply': 3414166606, 'self_reported_market_cap': 24650985931.97799, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 7.220205917501727, 'volume_24h': 253931271.30099422, 'volume_change_24h': -11.339, 'percent_change_1h': -0.68928216, 'percent_change_24h': -2.33508124, 'percent_change_7d': -1.57426351, 'percent_change_30d': -7.15873422, 'percent_change_60d': 10.91285127, 'percent_change_90d': 17.52034532, 'market_cap': 18137371427.235313, 'market_cap_dominance': 0.763, 'fully_diluted_market_cap': 36888772652.48, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 74, 'name': 'Dogecoin', 'symbol': 'DOGE', 'slug': 'dogecoin', 'num_market_pairs': 1025, 'date_added': '2013-12-15T00:00:00.000Z', 'tags': ['mineable', 'pow', 'scrypt', 'medium-of-exchange', 'memes', 'payments', 'doggone-doggerel', 'bnb-chain', 'ftx-bankruptcy-estate'], 'max_supply': None, 'circulating_supply': 145151856383.70523, 'total_supply': 145151856383.70523, 'infinite_supply': True, 'platform': None, 'cmc_rank': 9, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:55:00.000Z', 'quote': {'USD': {'price': 0.124173589837295, 'volume_24h': 812603351.3701594, 'volume_change_24h': -22.589, 'percent_change_1h': -0.97964354, 'percent_change_24h': 1.64740313, 'percent_change_7d': 13.41038645, 'percent_change_30d': -7.50461585, 'percent_change_60d': -20.45761899, 'percent_change_90d': -16.73450328, 'market_cap': 18024027078.712162, 'market_cap_dominance': 0.7582, 'fully_diluted_market_cap': 18024027078.71, 'tvl': None, 'last_updated': '2024-07-17T11:55:00.000Z'}}}, {'id': 2010, 'name': 'Cardano', 'symbol': 'ADA', 'slug': 'cardano', 'num_market_pairs': 1213, 'date_added': '2017-10-01T00:00:00.000Z', 'tags': ['dpos', 'pos', 'platform', 'research', 'smart-contracts', 'staking', 'cardano-ecosystem', 'cardano', 'layer-1', 'sec-security-token', 'alleged-sec-securities'], 'max_supply': 45000000000, 'circulating_supply': 35886483198.554, 'total_supply': 37048613783.371, 'infinite_supply': False, 'platform': None, 'cmc_rank': 10, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 0.44582743135733394, 'volume_24h': 424155221.50482637, 'volume_change_24h': -17.4438, 'percent_change_1h': -0.52428042, 'percent_change_24h': 3.23045759, 'percent_change_7d': 16.42994373, 'percent_change_30d': 10.22147042, 'percent_change_60d': -7.98226114, 'percent_change_90d': -1.28999942, 'market_cap': 15999178624.859451, 'market_cap_dominance': 0.6733, 'fully_diluted_market_cap': 20062234411.08, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 1958, 'name': 'TRON', 'symbol': 'TRX', 'slug': 'tron', 'num_market_pairs': 1001, 'date_added': '2017-09-13T00:00:00.000Z', 'tags': ['media', 'payments', 'tron-ecosystem', 'layer-1', 'dwf-labs-portfolio', 'sec-security-token', 'alleged-sec-securities'], 'max_supply': None, 'circulating_supply': 87107723240.61296, 'total_supply': 87107760425.04483, 'infinite_supply': True, 'platform': None, 'cmc_rank': 11, 'self_reported_circulating_supply': 71659659264, 'self_reported_market_cap': 9649984666.079927, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 0.13466411597812097, 'volume_24h': 320496928.19484925, 'volume_change_24h': -27.3278, 'percent_change_1h': 0.03134974, 'percent_change_24h': 0.38898625, 'percent_change_7d': 3.52567298, 'percent_change_30d': 15.33851065, 'percent_change_60d': 8.8553765, 'percent_change_90d': 22.78626659, 'market_cap': 11730284545.063967, 'market_cap_dominance': 0.4934, 'fully_diluted_market_cap': 11730289552.47, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 5994, 'name': 'Shiba Inu', 'symbol': 'SHIB', 'slug': 'shiba-inu', 'num_market_pairs': 846, 'date_added': '2020-08-01T00:00:00.000Z', 'tags': ['memes', 'ethereum-ecosystem', 'doggone-doggerel'], 'max_supply': None, 'circulating_supply': 589270743113993.8, 'total_supply': 589519212467867.4, 'platform': {'id': 1027, 'name': 'Ethereum', 'symbol': 'ETH', 'slug': 'ethereum', 'token_address': '0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce'}, 'infinite_supply': False, 'cmc_rank': 12, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 1.9328357324870212e-05, 'volume_24h': 484313748.3462978, 'volume_change_24h': -32.0363, 'percent_change_1h': 0.13788412, 'percent_change_24h': 0.16280342, 'percent_change_7d': 15.58935383, 'percent_change_30d': -3.15363042, 'percent_change_60d': -22.93485979, 'percent_change_90d': -13.62609592, 'market_cap': 11389635483.999075, 'market_cap_dominance': 0.4791, 'fully_diluted_market_cap': 11394437988.46, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 5805, 'name': 'Avalanche', 'symbol': 'AVAX', 'slug': 'avalanche', 'num_market_pairs': 752, 'date_added': '2020-07-13T00:00:00.000Z', 'tags': ['defi', 'smart-contracts', 'three-arrows-capital-portfolio', 'polychain-capital-portfolio', 'avalanche-ecosystem', 'cms-holdings-portfolio', 'dragonfly-capital-portfolio', 'moonriver-ecosystem', 'injective-ecosystem', 'real-world-assets', 'layer-1'], 'max_supply': 715748719, 'circulating_supply': 394688210.3669582, 'total_supply': 444034580.3669582, 'infinite_supply': False, 'platform': None, 'cmc_rank': 13, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 28.17394823366332, 'volume_24h': 445378643.2369945, 'volume_change_24h': 8.1925, 'percent_change_1h': -1.40467829, 'percent_change_24h': 3.50296093, 'percent_change_7d': 4.59962839, 'percent_change_30d': -1.55128421, 'percent_change_60d': -24.81821072, 'percent_change_90d': -19.73123583, 'market_cap': 11119925207.315899, 'market_cap_dominance': 0.4678, 'fully_diluted_market_cap': 20165467357.42, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 6636, 'name': 'Polkadot', 'symbol': 'DOT', 'slug': 'polkadot-new', 'num_market_pairs': 793, 'date_added': '2020-08-19T00:00:00.000Z', 'tags': ['substrate', 'polkadot', 'binance-chain', 'polkadot-ecosystem', 'three-arrows-capital-portfolio', 'polychain-capital-portfolio', 'arrington-xrp-capital-portfolio', 'blockchain-capital-portfolio', 'boostvc-portfolio', 'cms-holdings-portfolio', 'coinfund-portfolio', 'fabric-ventures-portfolio', 'fenbushi-capital-portfolio', 'hashkey-capital-portfolio', 'kenetic-capital-portfolio', '1confirmation-portfolio', 'placeholder-ventures-portfolio', 'pantera-capital-portfolio', 'exnetwork-capital-portfolio', 'web3', 'spartan-group', 'injective-ecosystem', 'bnb-chain', 'layer-1'], 'max_supply': None, 'circulating_supply': 1437953431.368154, 'total_supply': 1437953431.368154, 'infinite_supply': True, 'platform': None, 'cmc_rank': 14, 'self_reported_circulating_supply': 1469841795.4022434, 'self_reported_market_cap': 9470358969.344936, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 6.443114489578952, 'volume_24h': 203767585.0865228, 'volume_change_24h': -7.0402, 'percent_change_1h': -0.61932852, 'percent_change_24h': 2.63259181, 'percent_change_7d': 5.23403037, 'percent_change_30d': 4.02892556, 'percent_change_60d': -10.50496699, 'percent_change_90d': -3.92833578, 'market_cap': 9264898588.987926, 'market_cap_dominance': 0.3898, 'fully_diluted_market_cap': 9264898588.99, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}, {'id': 1975, 'name': 'Chainlink', 'symbol': 'LINK', 'slug': 'chainlink', 'num_market_pairs': 1817, 'date_added': '2017-09-20T00:00:00.000Z', 'tags': ['platform', 'defi', 'oracles', 'smart-contracts', 'substrate', 'polkadot', 'avalanche-ecosystem', 'solana-ecosystem', 'framework-ventures-portfolio', 'polygon-ecosystem', 'fantom-ecosystem', 'cardano-ecosystem', 'web3', 'near-protocol-ecosystem', 'arbitrum-ecosytem', 'cardano', 'injective-ecosystem', 'optimism-ecosystem', 'real-world-assets', 'celsius-bankruptcy-estate'], 'max_supply': None, 'circulating_supply': 608099970.4527867, 'total_supply': 1000000000, 'platform': {'id': 1027, 'name': 'Ethereum', 'symbol': 'ETH', 'slug': 'ethereum', 'token_address': '0x514910771af9ca656af840dff83e8264ecf986ca'}, 'infinite_supply': False, 'cmc_rank': 15, 'self_reported_circulating_supply': None, 'self_reported_market_cap': None, 'tvl_ratio': None, 'last_updated': '2024-07-17T11:54:00.000Z', 'quote': {'USD': {'price': 14.334612082769768, 'volume_24h': 346644916.9890132, 'volume_change_24h': -9.6771, 'percent_change_1h': -0.65909468, 'percent_change_24h': 1.78882201, 'percent_change_7d': 11.01146091, 'percent_change_30d': -0.03753733, 'percent_change_60d': -11.3902048, 'percent_change_90d': 7.21066877, 'market_cap': 8716877183.984455, 'market_cap_dominance': 0.3667, 'fully_diluted_market_cap': 14334612082.77, 'tvl': None, 'last_updated': '2024-07-17T11:54:00.000Z'}}}]}
    api Runner completed
    


    ---------------------------------------------------------------------------

    KeyboardInterrupt                         Traceback (most recent call last)

    Cell In[11], line 8
          6     api_runner()
          7     print('api Runner completed')
    ----> 8     sleep(60) # sleep for 1 minutes
          9 exit()
    

    KeyboardInterrupt: 



```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>name</th>
      <th>symbol</th>
      <th>slug</th>
      <th>num_market_pairs</th>
      <th>date_added</th>
      <th>tags</th>
      <th>max_supply</th>
      <th>circulating_supply</th>
      <th>total_supply</th>
      <th>infinite_supply</th>
      <th>platform</th>
      <th>cmc_rank</th>
      <th>self_reported_circulating_supply</th>
      <th>self_reported_market_cap</th>
      <th>tvl_ratio</th>
      <th>last_updated</th>
      <th>quote.USD.price</th>
      <th>quote.USD.volume_24h</th>
      <th>quote.USD.volume_change_24h</th>
      <th>quote.USD.percent_change_1h</th>
      <th>quote.USD.percent_change_24h</th>
      <th>quote.USD.percent_change_7d</th>
      <th>quote.USD.percent_change_30d</th>
      <th>quote.USD.percent_change_60d</th>
      <th>quote.USD.percent_change_90d</th>
      <th>quote.USD.market_cap</th>
      <th>quote.USD.market_cap_dominance</th>
      <th>quote.USD.fully_diluted_market_cap</th>
      <th>quote.USD.tvl</th>
      <th>quote.USD.last_updated</th>
      <th>platform.id</th>
      <th>platform.name</th>
      <th>platform.symbol</th>
      <th>platform.slug</th>
      <th>platform.token_address</th>
      <th>timestamp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Bitcoin</td>
      <td>BTC</td>
      <td>bitcoin</td>
      <td>11605</td>
      <td>2010-07-13T00:00:00.000Z</td>
      <td>[mineable, pow, sha-256, store-of-value, state...</td>
      <td>21000000.00000</td>
      <td>19726856.00000</td>
      <td>19726856.00000</td>
      <td>False</td>
      <td>NaN</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:55:00.000Z</td>
      <td>64723.61057</td>
      <td>37995372737.42730</td>
      <td>-5.01210</td>
      <td>-0.62572</td>
      <td>1.56736</td>
      <td>10.62718</td>
      <td>-1.58852</td>
      <td>-3.68419</td>
      <td>3.14370</td>
      <td>1276793345595.19800</td>
      <td>53.70980</td>
      <td>1359195822055.93994</td>
      <td>None</td>
      <td>2024-07-17T11:55:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1027</td>
      <td>Ethereum</td>
      <td>ETH</td>
      <td>ethereum</td>
      <td>9144</td>
      <td>2015-08-07T00:00:00.000Z</td>
      <td>[pos, smart-contracts, ethereum-ecosystem, coi...</td>
      <td>NaN</td>
      <td>120221218.02997</td>
      <td>120221218.02997</td>
      <td>True</td>
      <td>NaN</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>3449.45831</td>
      <td>19151313483.84790</td>
      <td>-3.30760</td>
      <td>-0.91889</td>
      <td>0.92089</td>
      <td>11.23546</td>
      <td>-2.01435</td>
      <td>9.88936</td>
      <td>13.04704</td>
      <td>414698079445.23553</td>
      <td>17.44460</td>
      <td>414698079445.23999</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>2</th>
      <td>825</td>
      <td>Tether USDt</td>
      <td>USDT</td>
      <td>tether</td>
      <td>91758</td>
      <td>2015-02-25T00:00:00.000Z</td>
      <td>[stablecoin, asset-backed-stablecoin, avalanch...</td>
      <td>NaN</td>
      <td>113224555138.64410</td>
      <td>117072162581.78760</td>
      <td>True</td>
      <td>NaN</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>1.00031</td>
      <td>70168361530.56512</td>
      <td>-4.69890</td>
      <td>0.00944</td>
      <td>-0.01274</td>
      <td>0.03935</td>
      <td>0.10155</td>
      <td>-0.00421</td>
      <td>-0.04924</td>
      <td>113260032017.19405</td>
      <td>4.76440</td>
      <td>117108845038.95000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>1027.00000</td>
      <td>Ethereum</td>
      <td>ETH</td>
      <td>ethereum</td>
      <td>0xdac17f958d2ee523a2206206994597c13d831ec7</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1839</td>
      <td>BNB</td>
      <td>BNB</td>
      <td>bnb</td>
      <td>2192</td>
      <td>2017-07-25T00:00:00.000Z</td>
      <td>[marketplace, centralized-exchange, payments, ...</td>
      <td>NaN</td>
      <td>147582069.67746</td>
      <td>147582069.67746</td>
      <td>False</td>
      <td>NaN</td>
      <td>4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>575.62216</td>
      <td>1876534604.85721</td>
      <td>-10.89470</td>
      <td>-0.74977</td>
      <td>0.83082</td>
      <td>9.05144</td>
      <td>-3.78312</td>
      <td>-0.78192</td>
      <td>5.11585</td>
      <td>84951509941.77232</td>
      <td>3.57360</td>
      <td>84951509941.77000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5426</td>
      <td>Solana</td>
      <td>SOL</td>
      <td>solana</td>
      <td>705</td>
      <td>2020-04-10T00:00:00.000Z</td>
      <td>[pos, platform, solana-ecosystem, cms-holdings...</td>
      <td>NaN</td>
      <td>464175526.78045</td>
      <td>580287041.18732</td>
      <td>True</td>
      <td>NaN</td>
      <td>5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>160.91142</td>
      <td>2654514490.78949</td>
      <td>-6.50610</td>
      <td>-1.06803</td>
      <td>2.37399</td>
      <td>12.40713</td>
      <td>12.02192</td>
      <td>-7.85117</td>
      <td>18.12620</td>
      <td>74691144874.81665</td>
      <td>3.14310</td>
      <td>93374813969.46001</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>5</th>
      <td>52</td>
      <td>XRP</td>
      <td>XRP</td>
      <td>xrp</td>
      <td>1354</td>
      <td>2013-08-04T00:00:00.000Z</td>
      <td>[medium-of-exchange, enterprise-solutions, arr...</td>
      <td>100000000000.00000</td>
      <td>55805339473.00000</td>
      <td>99987452475.00000</td>
      <td>False</td>
      <td>NaN</td>
      <td>6</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:55:00.000Z</td>
      <td>0.61271</td>
      <td>3703927536.29487</td>
      <td>58.53760</td>
      <td>-0.24694</td>
      <td>12.04140</td>
      <td>38.92497</td>
      <td>23.12027</td>
      <td>16.89664</td>
      <td>23.36795</td>
      <td>34192332293.09222</td>
      <td>1.43830</td>
      <td>61270718207.23000</td>
      <td>None</td>
      <td>2024-07-17T11:55:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>6</th>
      <td>3408</td>
      <td>USDC</td>
      <td>USDC</td>
      <td>usd-coin</td>
      <td>21018</td>
      <td>2018-10-08T00:00:00.000Z</td>
      <td>[medium-of-exchange, stablecoin, asset-backed-...</td>
      <td>NaN</td>
      <td>33922858555.54770</td>
      <td>33922858555.54770</td>
      <td>False</td>
      <td>NaN</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>1.00006</td>
      <td>7278092328.19487</td>
      <td>-6.62510</td>
      <td>0.01082</td>
      <td>-0.00264</td>
      <td>0.00472</td>
      <td>0.00549</td>
      <td>-0.00216</td>
      <td>-0.02575</td>
      <td>33924928524.80093</td>
      <td>1.42710</td>
      <td>33924928524.80000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>1027.00000</td>
      <td>Ethereum</td>
      <td>ETH</td>
      <td>ethereum</td>
      <td>0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>7</th>
      <td>11419</td>
      <td>Toncoin</td>
      <td>TON</td>
      <td>toncoin</td>
      <td>462</td>
      <td>2021-08-26T13:40:22.000Z</td>
      <td>[pos, layer-1, ftx-bankruptcy-estate, dwf-labs...</td>
      <td>NaN</td>
      <td>2512029661.54614</td>
      <td>5109102576.01718</td>
      <td>True</td>
      <td>NaN</td>
      <td>8</td>
      <td>3414166606.00000</td>
      <td>24650985931.97799</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>7.22021</td>
      <td>253931271.30099</td>
      <td>-11.33900</td>
      <td>-0.68928</td>
      <td>-2.33508</td>
      <td>-1.57426</td>
      <td>-7.15873</td>
      <td>10.91285</td>
      <td>17.52035</td>
      <td>18137371427.23531</td>
      <td>0.76300</td>
      <td>36888772652.48000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>8</th>
      <td>74</td>
      <td>Dogecoin</td>
      <td>DOGE</td>
      <td>dogecoin</td>
      <td>1025</td>
      <td>2013-12-15T00:00:00.000Z</td>
      <td>[mineable, pow, scrypt, medium-of-exchange, me...</td>
      <td>NaN</td>
      <td>145151856383.70523</td>
      <td>145151856383.70523</td>
      <td>True</td>
      <td>NaN</td>
      <td>9</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:55:00.000Z</td>
      <td>0.12417</td>
      <td>812603351.37016</td>
      <td>-22.58900</td>
      <td>-0.97964</td>
      <td>1.64740</td>
      <td>13.41039</td>
      <td>-7.50462</td>
      <td>-20.45762</td>
      <td>-16.73450</td>
      <td>18024027078.71216</td>
      <td>0.75820</td>
      <td>18024027078.71000</td>
      <td>None</td>
      <td>2024-07-17T11:55:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2010</td>
      <td>Cardano</td>
      <td>ADA</td>
      <td>cardano</td>
      <td>1213</td>
      <td>2017-10-01T00:00:00.000Z</td>
      <td>[dpos, pos, platform, research, smart-contract...</td>
      <td>45000000000.00000</td>
      <td>35886483198.55400</td>
      <td>37048613783.37100</td>
      <td>False</td>
      <td>NaN</td>
      <td>10</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>0.44583</td>
      <td>424155221.50483</td>
      <td>-17.44380</td>
      <td>-0.52428</td>
      <td>3.23046</td>
      <td>16.42994</td>
      <td>10.22147</td>
      <td>-7.98226</td>
      <td>-1.29000</td>
      <td>15999178624.85945</td>
      <td>0.67330</td>
      <td>20062234411.08000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1958</td>
      <td>TRON</td>
      <td>TRX</td>
      <td>tron</td>
      <td>1001</td>
      <td>2017-09-13T00:00:00.000Z</td>
      <td>[media, payments, tron-ecosystem, layer-1, dwf...</td>
      <td>NaN</td>
      <td>87107723240.61296</td>
      <td>87107760425.04483</td>
      <td>True</td>
      <td>NaN</td>
      <td>11</td>
      <td>71659659264.00000</td>
      <td>9649984666.07993</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>0.13466</td>
      <td>320496928.19485</td>
      <td>-27.32780</td>
      <td>0.03135</td>
      <td>0.38899</td>
      <td>3.52567</td>
      <td>15.33851</td>
      <td>8.85538</td>
      <td>22.78627</td>
      <td>11730284545.06397</td>
      <td>0.49340</td>
      <td>11730289552.47000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>11</th>
      <td>5994</td>
      <td>Shiba Inu</td>
      <td>SHIB</td>
      <td>shiba-inu</td>
      <td>846</td>
      <td>2020-08-01T00:00:00.000Z</td>
      <td>[memes, ethereum-ecosystem, doggone-doggerel]</td>
      <td>NaN</td>
      <td>589270743113993.75000</td>
      <td>589519212467867.37500</td>
      <td>False</td>
      <td>NaN</td>
      <td>12</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>0.00002</td>
      <td>484313748.34630</td>
      <td>-32.03630</td>
      <td>0.13788</td>
      <td>0.16280</td>
      <td>15.58935</td>
      <td>-3.15363</td>
      <td>-22.93486</td>
      <td>-13.62610</td>
      <td>11389635483.99907</td>
      <td>0.47910</td>
      <td>11394437988.46000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>1027.00000</td>
      <td>Ethereum</td>
      <td>ETH</td>
      <td>ethereum</td>
      <td>0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>12</th>
      <td>5805</td>
      <td>Avalanche</td>
      <td>AVAX</td>
      <td>avalanche</td>
      <td>752</td>
      <td>2020-07-13T00:00:00.000Z</td>
      <td>[defi, smart-contracts, three-arrows-capital-p...</td>
      <td>715748719.00000</td>
      <td>394688210.36696</td>
      <td>444034580.36696</td>
      <td>False</td>
      <td>NaN</td>
      <td>13</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>28.17395</td>
      <td>445378643.23699</td>
      <td>8.19250</td>
      <td>-1.40468</td>
      <td>3.50296</td>
      <td>4.59963</td>
      <td>-1.55128</td>
      <td>-24.81821</td>
      <td>-19.73124</td>
      <td>11119925207.31590</td>
      <td>0.46780</td>
      <td>20165467357.42000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>13</th>
      <td>6636</td>
      <td>Polkadot</td>
      <td>DOT</td>
      <td>polkadot-new</td>
      <td>793</td>
      <td>2020-08-19T00:00:00.000Z</td>
      <td>[substrate, polkadot, binance-chain, polkadot-...</td>
      <td>NaN</td>
      <td>1437953431.36815</td>
      <td>1437953431.36815</td>
      <td>True</td>
      <td>NaN</td>
      <td>14</td>
      <td>1469841795.40224</td>
      <td>9470358969.34494</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>6.44311</td>
      <td>203767585.08652</td>
      <td>-7.04020</td>
      <td>-0.61933</td>
      <td>2.63259</td>
      <td>5.23403</td>
      <td>4.02893</td>
      <td>-10.50497</td>
      <td>-3.92834</td>
      <td>9264898588.98793</td>
      <td>0.38980</td>
      <td>9264898588.99000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1975</td>
      <td>Chainlink</td>
      <td>LINK</td>
      <td>chainlink</td>
      <td>1817</td>
      <td>2017-09-20T00:00:00.000Z</td>
      <td>[platform, defi, oracles, smart-contracts, sub...</td>
      <td>NaN</td>
      <td>608099970.45279</td>
      <td>1000000000.00000</td>
      <td>False</td>
      <td>NaN</td>
      <td>15</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>14.33461</td>
      <td>346644916.98901</td>
      <td>-9.67710</td>
      <td>-0.65909</td>
      <td>1.78882</td>
      <td>11.01146</td>
      <td>-0.03754</td>
      <td>-11.39020</td>
      <td>7.21067</td>
      <td>8716877183.98446</td>
      <td>0.36670</td>
      <td>14334612082.77000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>1027.00000</td>
      <td>Ethereum</td>
      <td>ETH</td>
      <td>ethereum</td>
      <td>0x514910771af9ca656af840dff83e8264ecf986ca</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.set_option('display.float_format',lambda x:'%.5f' % x)
```


```python
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>name</th>
      <th>symbol</th>
      <th>slug</th>
      <th>num_market_pairs</th>
      <th>date_added</th>
      <th>tags</th>
      <th>max_supply</th>
      <th>circulating_supply</th>
      <th>total_supply</th>
      <th>infinite_supply</th>
      <th>platform</th>
      <th>cmc_rank</th>
      <th>self_reported_circulating_supply</th>
      <th>self_reported_market_cap</th>
      <th>tvl_ratio</th>
      <th>last_updated</th>
      <th>quote.USD.price</th>
      <th>quote.USD.volume_24h</th>
      <th>quote.USD.volume_change_24h</th>
      <th>quote.USD.percent_change_1h</th>
      <th>quote.USD.percent_change_24h</th>
      <th>quote.USD.percent_change_7d</th>
      <th>quote.USD.percent_change_30d</th>
      <th>quote.USD.percent_change_60d</th>
      <th>quote.USD.percent_change_90d</th>
      <th>quote.USD.market_cap</th>
      <th>quote.USD.market_cap_dominance</th>
      <th>quote.USD.fully_diluted_market_cap</th>
      <th>quote.USD.tvl</th>
      <th>quote.USD.last_updated</th>
      <th>platform.id</th>
      <th>platform.name</th>
      <th>platform.symbol</th>
      <th>platform.slug</th>
      <th>platform.token_address</th>
      <th>timestamp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Bitcoin</td>
      <td>BTC</td>
      <td>bitcoin</td>
      <td>11605</td>
      <td>2010-07-13T00:00:00.000Z</td>
      <td>[mineable, pow, sha-256, store-of-value, state...</td>
      <td>21000000.00000</td>
      <td>19726856.00000</td>
      <td>19726856.00000</td>
      <td>False</td>
      <td>NaN</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:55:00.000Z</td>
      <td>64723.61057</td>
      <td>37995372737.42730</td>
      <td>-5.01210</td>
      <td>-0.62572</td>
      <td>1.56736</td>
      <td>10.62718</td>
      <td>-1.58852</td>
      <td>-3.68419</td>
      <td>3.14370</td>
      <td>1276793345595.19800</td>
      <td>53.70980</td>
      <td>1359195822055.93994</td>
      <td>None</td>
      <td>2024-07-17T11:55:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1027</td>
      <td>Ethereum</td>
      <td>ETH</td>
      <td>ethereum</td>
      <td>9144</td>
      <td>2015-08-07T00:00:00.000Z</td>
      <td>[pos, smart-contracts, ethereum-ecosystem, coi...</td>
      <td>NaN</td>
      <td>120221218.02997</td>
      <td>120221218.02997</td>
      <td>True</td>
      <td>NaN</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>3449.45831</td>
      <td>19151313483.84790</td>
      <td>-3.30760</td>
      <td>-0.91889</td>
      <td>0.92089</td>
      <td>11.23546</td>
      <td>-2.01435</td>
      <td>9.88936</td>
      <td>13.04704</td>
      <td>414698079445.23553</td>
      <td>17.44460</td>
      <td>414698079445.23999</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>2</th>
      <td>825</td>
      <td>Tether USDt</td>
      <td>USDT</td>
      <td>tether</td>
      <td>91758</td>
      <td>2015-02-25T00:00:00.000Z</td>
      <td>[stablecoin, asset-backed-stablecoin, avalanch...</td>
      <td>NaN</td>
      <td>113224555138.64410</td>
      <td>117072162581.78760</td>
      <td>True</td>
      <td>NaN</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>1.00031</td>
      <td>70168361530.56512</td>
      <td>-4.69890</td>
      <td>0.00944</td>
      <td>-0.01274</td>
      <td>0.03935</td>
      <td>0.10155</td>
      <td>-0.00421</td>
      <td>-0.04924</td>
      <td>113260032017.19405</td>
      <td>4.76440</td>
      <td>117108845038.95000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>1027.00000</td>
      <td>Ethereum</td>
      <td>ETH</td>
      <td>ethereum</td>
      <td>0xdac17f958d2ee523a2206206994597c13d831ec7</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1839</td>
      <td>BNB</td>
      <td>BNB</td>
      <td>bnb</td>
      <td>2192</td>
      <td>2017-07-25T00:00:00.000Z</td>
      <td>[marketplace, centralized-exchange, payments, ...</td>
      <td>NaN</td>
      <td>147582069.67746</td>
      <td>147582069.67746</td>
      <td>False</td>
      <td>NaN</td>
      <td>4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>575.62216</td>
      <td>1876534604.85721</td>
      <td>-10.89470</td>
      <td>-0.74977</td>
      <td>0.83082</td>
      <td>9.05144</td>
      <td>-3.78312</td>
      <td>-0.78192</td>
      <td>5.11585</td>
      <td>84951509941.77232</td>
      <td>3.57360</td>
      <td>84951509941.77000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5426</td>
      <td>Solana</td>
      <td>SOL</td>
      <td>solana</td>
      <td>705</td>
      <td>2020-04-10T00:00:00.000Z</td>
      <td>[pos, platform, solana-ecosystem, cms-holdings...</td>
      <td>NaN</td>
      <td>464175526.78045</td>
      <td>580287041.18732</td>
      <td>True</td>
      <td>NaN</td>
      <td>5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>160.91142</td>
      <td>2654514490.78949</td>
      <td>-6.50610</td>
      <td>-1.06803</td>
      <td>2.37399</td>
      <td>12.40713</td>
      <td>12.02192</td>
      <td>-7.85117</td>
      <td>18.12620</td>
      <td>74691144874.81665</td>
      <td>3.14310</td>
      <td>93374813969.46001</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>5</th>
      <td>52</td>
      <td>XRP</td>
      <td>XRP</td>
      <td>xrp</td>
      <td>1354</td>
      <td>2013-08-04T00:00:00.000Z</td>
      <td>[medium-of-exchange, enterprise-solutions, arr...</td>
      <td>100000000000.00000</td>
      <td>55805339473.00000</td>
      <td>99987452475.00000</td>
      <td>False</td>
      <td>NaN</td>
      <td>6</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:55:00.000Z</td>
      <td>0.61271</td>
      <td>3703927536.29487</td>
      <td>58.53760</td>
      <td>-0.24694</td>
      <td>12.04140</td>
      <td>38.92497</td>
      <td>23.12027</td>
      <td>16.89664</td>
      <td>23.36795</td>
      <td>34192332293.09222</td>
      <td>1.43830</td>
      <td>61270718207.23000</td>
      <td>None</td>
      <td>2024-07-17T11:55:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>6</th>
      <td>3408</td>
      <td>USDC</td>
      <td>USDC</td>
      <td>usd-coin</td>
      <td>21018</td>
      <td>2018-10-08T00:00:00.000Z</td>
      <td>[medium-of-exchange, stablecoin, asset-backed-...</td>
      <td>NaN</td>
      <td>33922858555.54770</td>
      <td>33922858555.54770</td>
      <td>False</td>
      <td>NaN</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>1.00006</td>
      <td>7278092328.19487</td>
      <td>-6.62510</td>
      <td>0.01082</td>
      <td>-0.00264</td>
      <td>0.00472</td>
      <td>0.00549</td>
      <td>-0.00216</td>
      <td>-0.02575</td>
      <td>33924928524.80093</td>
      <td>1.42710</td>
      <td>33924928524.80000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>1027.00000</td>
      <td>Ethereum</td>
      <td>ETH</td>
      <td>ethereum</td>
      <td>0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>7</th>
      <td>11419</td>
      <td>Toncoin</td>
      <td>TON</td>
      <td>toncoin</td>
      <td>462</td>
      <td>2021-08-26T13:40:22.000Z</td>
      <td>[pos, layer-1, ftx-bankruptcy-estate, dwf-labs...</td>
      <td>NaN</td>
      <td>2512029661.54614</td>
      <td>5109102576.01718</td>
      <td>True</td>
      <td>NaN</td>
      <td>8</td>
      <td>3414166606.00000</td>
      <td>24650985931.97799</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>7.22021</td>
      <td>253931271.30099</td>
      <td>-11.33900</td>
      <td>-0.68928</td>
      <td>-2.33508</td>
      <td>-1.57426</td>
      <td>-7.15873</td>
      <td>10.91285</td>
      <td>17.52035</td>
      <td>18137371427.23531</td>
      <td>0.76300</td>
      <td>36888772652.48000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>8</th>
      <td>74</td>
      <td>Dogecoin</td>
      <td>DOGE</td>
      <td>dogecoin</td>
      <td>1025</td>
      <td>2013-12-15T00:00:00.000Z</td>
      <td>[mineable, pow, scrypt, medium-of-exchange, me...</td>
      <td>NaN</td>
      <td>145151856383.70523</td>
      <td>145151856383.70523</td>
      <td>True</td>
      <td>NaN</td>
      <td>9</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:55:00.000Z</td>
      <td>0.12417</td>
      <td>812603351.37016</td>
      <td>-22.58900</td>
      <td>-0.97964</td>
      <td>1.64740</td>
      <td>13.41039</td>
      <td>-7.50462</td>
      <td>-20.45762</td>
      <td>-16.73450</td>
      <td>18024027078.71216</td>
      <td>0.75820</td>
      <td>18024027078.71000</td>
      <td>None</td>
      <td>2024-07-17T11:55:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2010</td>
      <td>Cardano</td>
      <td>ADA</td>
      <td>cardano</td>
      <td>1213</td>
      <td>2017-10-01T00:00:00.000Z</td>
      <td>[dpos, pos, platform, research, smart-contract...</td>
      <td>45000000000.00000</td>
      <td>35886483198.55400</td>
      <td>37048613783.37100</td>
      <td>False</td>
      <td>NaN</td>
      <td>10</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>0.44583</td>
      <td>424155221.50483</td>
      <td>-17.44380</td>
      <td>-0.52428</td>
      <td>3.23046</td>
      <td>16.42994</td>
      <td>10.22147</td>
      <td>-7.98226</td>
      <td>-1.29000</td>
      <td>15999178624.85945</td>
      <td>0.67330</td>
      <td>20062234411.08000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1958</td>
      <td>TRON</td>
      <td>TRX</td>
      <td>tron</td>
      <td>1001</td>
      <td>2017-09-13T00:00:00.000Z</td>
      <td>[media, payments, tron-ecosystem, layer-1, dwf...</td>
      <td>NaN</td>
      <td>87107723240.61296</td>
      <td>87107760425.04483</td>
      <td>True</td>
      <td>NaN</td>
      <td>11</td>
      <td>71659659264.00000</td>
      <td>9649984666.07993</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>0.13466</td>
      <td>320496928.19485</td>
      <td>-27.32780</td>
      <td>0.03135</td>
      <td>0.38899</td>
      <td>3.52567</td>
      <td>15.33851</td>
      <td>8.85538</td>
      <td>22.78627</td>
      <td>11730284545.06397</td>
      <td>0.49340</td>
      <td>11730289552.47000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>11</th>
      <td>5994</td>
      <td>Shiba Inu</td>
      <td>SHIB</td>
      <td>shiba-inu</td>
      <td>846</td>
      <td>2020-08-01T00:00:00.000Z</td>
      <td>[memes, ethereum-ecosystem, doggone-doggerel]</td>
      <td>NaN</td>
      <td>589270743113993.75000</td>
      <td>589519212467867.37500</td>
      <td>False</td>
      <td>NaN</td>
      <td>12</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>0.00002</td>
      <td>484313748.34630</td>
      <td>-32.03630</td>
      <td>0.13788</td>
      <td>0.16280</td>
      <td>15.58935</td>
      <td>-3.15363</td>
      <td>-22.93486</td>
      <td>-13.62610</td>
      <td>11389635483.99907</td>
      <td>0.47910</td>
      <td>11394437988.46000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>1027.00000</td>
      <td>Ethereum</td>
      <td>ETH</td>
      <td>ethereum</td>
      <td>0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>12</th>
      <td>5805</td>
      <td>Avalanche</td>
      <td>AVAX</td>
      <td>avalanche</td>
      <td>752</td>
      <td>2020-07-13T00:00:00.000Z</td>
      <td>[defi, smart-contracts, three-arrows-capital-p...</td>
      <td>715748719.00000</td>
      <td>394688210.36696</td>
      <td>444034580.36696</td>
      <td>False</td>
      <td>NaN</td>
      <td>13</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>28.17395</td>
      <td>445378643.23699</td>
      <td>8.19250</td>
      <td>-1.40468</td>
      <td>3.50296</td>
      <td>4.59963</td>
      <td>-1.55128</td>
      <td>-24.81821</td>
      <td>-19.73124</td>
      <td>11119925207.31590</td>
      <td>0.46780</td>
      <td>20165467357.42000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>13</th>
      <td>6636</td>
      <td>Polkadot</td>
      <td>DOT</td>
      <td>polkadot-new</td>
      <td>793</td>
      <td>2020-08-19T00:00:00.000Z</td>
      <td>[substrate, polkadot, binance-chain, polkadot-...</td>
      <td>NaN</td>
      <td>1437953431.36815</td>
      <td>1437953431.36815</td>
      <td>True</td>
      <td>NaN</td>
      <td>14</td>
      <td>1469841795.40224</td>
      <td>9470358969.34494</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>6.44311</td>
      <td>203767585.08652</td>
      <td>-7.04020</td>
      <td>-0.61933</td>
      <td>2.63259</td>
      <td>5.23403</td>
      <td>4.02893</td>
      <td>-10.50497</td>
      <td>-3.92834</td>
      <td>9264898588.98793</td>
      <td>0.38980</td>
      <td>9264898588.99000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1975</td>
      <td>Chainlink</td>
      <td>LINK</td>
      <td>chainlink</td>
      <td>1817</td>
      <td>2017-09-20T00:00:00.000Z</td>
      <td>[platform, defi, oracles, smart-contracts, sub...</td>
      <td>NaN</td>
      <td>608099970.45279</td>
      <td>1000000000.00000</td>
      <td>False</td>
      <td>NaN</td>
      <td>15</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>14.33461</td>
      <td>346644916.98901</td>
      <td>-9.67710</td>
      <td>-0.65909</td>
      <td>1.78882</td>
      <td>11.01146</td>
      <td>-0.03754</td>
      <td>-11.39020</td>
      <td>7.21067</td>
      <td>8716877183.98446</td>
      <td>0.36670</td>
      <td>14334612082.77000</td>
      <td>None</td>
      <td>2024-07-17T11:54:00.000Z</td>
      <td>1027.00000</td>
      <td>Ethereum</td>
      <td>ETH</td>
      <td>ethereum</td>
      <td>0x514910771af9ca656af840dff83e8264ecf986ca</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
  </tbody>
</table>
</div>




```python
df3 = df.groupby('name',sort=False)[['quote.USD.percent_change_1h','quote.USD.percent_change_24h','quote.USD.percent_change_7d','quote.USD.percent_change_30d','quote.USD.percent_change_60d','quote.USD.percent_change_90d']].mean()
print(df3)
```

                 quote.USD.percent_change_1h  quote.USD.percent_change_24h  \
    name                                                                     
    Bitcoin                         -0.62572                       1.56736   
    Ethereum                        -0.91889                       0.92089   
    Tether USDt                      0.00944                      -0.01274   
    BNB                             -0.74977                       0.83082   
    Solana                          -1.06803                       2.37399   
    XRP                             -0.24694                      12.04140   
    USDC                             0.01082                      -0.00264   
    Toncoin                         -0.68928                      -2.33508   
    Dogecoin                        -0.97964                       1.64740   
    Cardano                         -0.52428                       3.23046   
    TRON                             0.03135                       0.38899   
    Shiba Inu                        0.13788                       0.16280   
    Avalanche                       -1.40468                       3.50296   
    Polkadot                        -0.61933                       2.63259   
    Chainlink                       -0.65909                       1.78882   
    
                 quote.USD.percent_change_7d  quote.USD.percent_change_30d  \
    name                                                                     
    Bitcoin                         10.62718                      -1.58852   
    Ethereum                        11.23546                      -2.01435   
    Tether USDt                      0.03935                       0.10155   
    BNB                              9.05144                      -3.78312   
    Solana                          12.40713                      12.02192   
    XRP                             38.92497                      23.12027   
    USDC                             0.00472                       0.00549   
    Toncoin                         -1.57426                      -7.15873   
    Dogecoin                        13.41039                      -7.50462   
    Cardano                         16.42994                      10.22147   
    TRON                             3.52567                      15.33851   
    Shiba Inu                       15.58935                      -3.15363   
    Avalanche                        4.59963                      -1.55128   
    Polkadot                         5.23403                       4.02893   
    Chainlink                       11.01146                      -0.03754   
    
                 quote.USD.percent_change_60d  quote.USD.percent_change_90d  
    name                                                                     
    Bitcoin                          -3.68419                       3.14370  
    Ethereum                          9.88936                      13.04704  
    Tether USDt                      -0.00421                      -0.04924  
    BNB                              -0.78192                       5.11585  
    Solana                           -7.85117                      18.12620  
    XRP                              16.89664                      23.36795  
    USDC                             -0.00216                      -0.02575  
    Toncoin                          10.91285                      17.52035  
    Dogecoin                        -20.45762                     -16.73450  
    Cardano                          -7.98226                      -1.29000  
    TRON                              8.85538                      22.78627  
    Shiba Inu                       -22.93486                     -13.62610  
    Avalanche                       -24.81821                     -19.73124  
    Polkadot                        -10.50497                      -3.92834  
    Chainlink                       -11.39020                       7.21067  
    


```python
df4=df3.stack()
df4
```




    name                                     
    Bitcoin      quote.USD.percent_change_1h     -0.62572
                 quote.USD.percent_change_24h     1.56736
                 quote.USD.percent_change_7d     10.62718
                 quote.USD.percent_change_30d    -1.58852
                 quote.USD.percent_change_60d    -3.68419
                 quote.USD.percent_change_90d     3.14370
    Ethereum     quote.USD.percent_change_1h     -0.91889
                 quote.USD.percent_change_24h     0.92089
                 quote.USD.percent_change_7d     11.23546
                 quote.USD.percent_change_30d    -2.01435
                 quote.USD.percent_change_60d     9.88936
                 quote.USD.percent_change_90d    13.04704
    Tether USDt  quote.USD.percent_change_1h      0.00944
                 quote.USD.percent_change_24h    -0.01274
                 quote.USD.percent_change_7d      0.03935
                 quote.USD.percent_change_30d     0.10155
                 quote.USD.percent_change_60d    -0.00421
                 quote.USD.percent_change_90d    -0.04924
    BNB          quote.USD.percent_change_1h     -0.74977
                 quote.USD.percent_change_24h     0.83082
                 quote.USD.percent_change_7d      9.05144
                 quote.USD.percent_change_30d    -3.78312
                 quote.USD.percent_change_60d    -0.78192
                 quote.USD.percent_change_90d     5.11585
    Solana       quote.USD.percent_change_1h     -1.06803
                 quote.USD.percent_change_24h     2.37399
                 quote.USD.percent_change_7d     12.40713
                 quote.USD.percent_change_30d    12.02192
                 quote.USD.percent_change_60d    -7.85117
                 quote.USD.percent_change_90d    18.12620
    XRP          quote.USD.percent_change_1h     -0.24694
                 quote.USD.percent_change_24h    12.04140
                 quote.USD.percent_change_7d     38.92497
                 quote.USD.percent_change_30d    23.12027
                 quote.USD.percent_change_60d    16.89664
                 quote.USD.percent_change_90d    23.36795
    USDC         quote.USD.percent_change_1h      0.01082
                 quote.USD.percent_change_24h    -0.00264
                 quote.USD.percent_change_7d      0.00472
                 quote.USD.percent_change_30d     0.00549
                 quote.USD.percent_change_60d    -0.00216
                 quote.USD.percent_change_90d    -0.02575
    Toncoin      quote.USD.percent_change_1h     -0.68928
                 quote.USD.percent_change_24h    -2.33508
                 quote.USD.percent_change_7d     -1.57426
                 quote.USD.percent_change_30d    -7.15873
                 quote.USD.percent_change_60d    10.91285
                 quote.USD.percent_change_90d    17.52035
    Dogecoin     quote.USD.percent_change_1h     -0.97964
                 quote.USD.percent_change_24h     1.64740
                 quote.USD.percent_change_7d     13.41039
                 quote.USD.percent_change_30d    -7.50462
                 quote.USD.percent_change_60d   -20.45762
                 quote.USD.percent_change_90d   -16.73450
    Cardano      quote.USD.percent_change_1h     -0.52428
                 quote.USD.percent_change_24h     3.23046
                 quote.USD.percent_change_7d     16.42994
                 quote.USD.percent_change_30d    10.22147
                 quote.USD.percent_change_60d    -7.98226
                 quote.USD.percent_change_90d    -1.29000
    TRON         quote.USD.percent_change_1h      0.03135
                 quote.USD.percent_change_24h     0.38899
                 quote.USD.percent_change_7d      3.52567
                 quote.USD.percent_change_30d    15.33851
                 quote.USD.percent_change_60d     8.85538
                 quote.USD.percent_change_90d    22.78627
    Shiba Inu    quote.USD.percent_change_1h      0.13788
                 quote.USD.percent_change_24h     0.16280
                 quote.USD.percent_change_7d     15.58935
                 quote.USD.percent_change_30d    -3.15363
                 quote.USD.percent_change_60d   -22.93486
                 quote.USD.percent_change_90d   -13.62610
    Avalanche    quote.USD.percent_change_1h     -1.40468
                 quote.USD.percent_change_24h     3.50296
                 quote.USD.percent_change_7d      4.59963
                 quote.USD.percent_change_30d    -1.55128
                 quote.USD.percent_change_60d   -24.81821
                 quote.USD.percent_change_90d   -19.73124
    Polkadot     quote.USD.percent_change_1h     -0.61933
                 quote.USD.percent_change_24h     2.63259
                 quote.USD.percent_change_7d      5.23403
                 quote.USD.percent_change_30d     4.02893
                 quote.USD.percent_change_60d   -10.50497
                 quote.USD.percent_change_90d    -3.92834
    Chainlink    quote.USD.percent_change_1h     -0.65909
                 quote.USD.percent_change_24h     1.78882
                 quote.USD.percent_change_7d     11.01146
                 quote.USD.percent_change_30d    -0.03754
                 quote.USD.percent_change_60d   -11.39020
                 quote.USD.percent_change_90d     7.21067
    dtype: float64




```python
type(df4)
```




    pandas.core.series.Series




```python
df5 = df4.to_frame(name='values')
df5
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>values</th>
    </tr>
    <tr>
      <th>name</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="6" valign="top">Bitcoin</th>
      <th>quote.USD.percent_change_1h</th>
      <td>-0.62572</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_24h</th>
      <td>1.56736</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_7d</th>
      <td>10.62718</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_30d</th>
      <td>-1.58852</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_60d</th>
      <td>-3.68419</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_90d</th>
      <td>3.14370</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">Ethereum</th>
      <th>quote.USD.percent_change_1h</th>
      <td>-0.91889</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_24h</th>
      <td>0.92089</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_7d</th>
      <td>11.23546</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_30d</th>
      <td>-2.01435</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_60d</th>
      <td>9.88936</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_90d</th>
      <td>13.04704</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">Tether USDt</th>
      <th>quote.USD.percent_change_1h</th>
      <td>0.00944</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_24h</th>
      <td>-0.01274</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_7d</th>
      <td>0.03935</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_30d</th>
      <td>0.10155</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_60d</th>
      <td>-0.00421</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_90d</th>
      <td>-0.04924</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">BNB</th>
      <th>quote.USD.percent_change_1h</th>
      <td>-0.74977</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_24h</th>
      <td>0.83082</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_7d</th>
      <td>9.05144</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_30d</th>
      <td>-3.78312</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_60d</th>
      <td>-0.78192</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_90d</th>
      <td>5.11585</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">Solana</th>
      <th>quote.USD.percent_change_1h</th>
      <td>-1.06803</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_24h</th>
      <td>2.37399</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_7d</th>
      <td>12.40713</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_30d</th>
      <td>12.02192</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_60d</th>
      <td>-7.85117</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_90d</th>
      <td>18.12620</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">XRP</th>
      <th>quote.USD.percent_change_1h</th>
      <td>-0.24694</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_24h</th>
      <td>12.04140</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_7d</th>
      <td>38.92497</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_30d</th>
      <td>23.12027</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_60d</th>
      <td>16.89664</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_90d</th>
      <td>23.36795</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">USDC</th>
      <th>quote.USD.percent_change_1h</th>
      <td>0.01082</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_24h</th>
      <td>-0.00264</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_7d</th>
      <td>0.00472</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_30d</th>
      <td>0.00549</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_60d</th>
      <td>-0.00216</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_90d</th>
      <td>-0.02575</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">Toncoin</th>
      <th>quote.USD.percent_change_1h</th>
      <td>-0.68928</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_24h</th>
      <td>-2.33508</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_7d</th>
      <td>-1.57426</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_30d</th>
      <td>-7.15873</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_60d</th>
      <td>10.91285</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_90d</th>
      <td>17.52035</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">Dogecoin</th>
      <th>quote.USD.percent_change_1h</th>
      <td>-0.97964</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_24h</th>
      <td>1.64740</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_7d</th>
      <td>13.41039</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_30d</th>
      <td>-7.50462</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_60d</th>
      <td>-20.45762</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_90d</th>
      <td>-16.73450</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">Cardano</th>
      <th>quote.USD.percent_change_1h</th>
      <td>-0.52428</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_24h</th>
      <td>3.23046</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_7d</th>
      <td>16.42994</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_30d</th>
      <td>10.22147</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_60d</th>
      <td>-7.98226</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_90d</th>
      <td>-1.29000</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">TRON</th>
      <th>quote.USD.percent_change_1h</th>
      <td>0.03135</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_24h</th>
      <td>0.38899</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_7d</th>
      <td>3.52567</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_30d</th>
      <td>15.33851</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_60d</th>
      <td>8.85538</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_90d</th>
      <td>22.78627</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">Shiba Inu</th>
      <th>quote.USD.percent_change_1h</th>
      <td>0.13788</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_24h</th>
      <td>0.16280</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_7d</th>
      <td>15.58935</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_30d</th>
      <td>-3.15363</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_60d</th>
      <td>-22.93486</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_90d</th>
      <td>-13.62610</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">Avalanche</th>
      <th>quote.USD.percent_change_1h</th>
      <td>-1.40468</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_24h</th>
      <td>3.50296</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_7d</th>
      <td>4.59963</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_30d</th>
      <td>-1.55128</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_60d</th>
      <td>-24.81821</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_90d</th>
      <td>-19.73124</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">Polkadot</th>
      <th>quote.USD.percent_change_1h</th>
      <td>-0.61933</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_24h</th>
      <td>2.63259</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_7d</th>
      <td>5.23403</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_30d</th>
      <td>4.02893</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_60d</th>
      <td>-10.50497</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_90d</th>
      <td>-3.92834</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">Chainlink</th>
      <th>quote.USD.percent_change_1h</th>
      <td>-0.65909</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_24h</th>
      <td>1.78882</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_7d</th>
      <td>11.01146</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_30d</th>
      <td>-0.03754</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_60d</th>
      <td>-11.39020</td>
    </tr>
    <tr>
      <th>quote.USD.percent_change_90d</th>
      <td>7.21067</td>
    </tr>
  </tbody>
</table>
</div>




```python
type(df5)
```




    pandas.core.frame.DataFrame




```python
df5.count()
```




    values    90
    dtype: int64




```python
index = pd.Index(range(90))

# Set the above DataFrame index object as the index
# using set_index() function
df6 = df5.reset_index()
df6
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>level_1</th>
      <th>values</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Bitcoin</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.62572</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Bitcoin</td>
      <td>quote.USD.percent_change_24h</td>
      <td>1.56736</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Bitcoin</td>
      <td>quote.USD.percent_change_7d</td>
      <td>10.62718</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Bitcoin</td>
      <td>quote.USD.percent_change_30d</td>
      <td>-1.58852</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Bitcoin</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-3.68419</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Bitcoin</td>
      <td>quote.USD.percent_change_90d</td>
      <td>3.14370</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Ethereum</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.91889</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Ethereum</td>
      <td>quote.USD.percent_change_24h</td>
      <td>0.92089</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Ethereum</td>
      <td>quote.USD.percent_change_7d</td>
      <td>11.23546</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Ethereum</td>
      <td>quote.USD.percent_change_30d</td>
      <td>-2.01435</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Ethereum</td>
      <td>quote.USD.percent_change_60d</td>
      <td>9.88936</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Ethereum</td>
      <td>quote.USD.percent_change_90d</td>
      <td>13.04704</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Tether USDt</td>
      <td>quote.USD.percent_change_1h</td>
      <td>0.00944</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Tether USDt</td>
      <td>quote.USD.percent_change_24h</td>
      <td>-0.01274</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Tether USDt</td>
      <td>quote.USD.percent_change_7d</td>
      <td>0.03935</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Tether USDt</td>
      <td>quote.USD.percent_change_30d</td>
      <td>0.10155</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Tether USDt</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-0.00421</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Tether USDt</td>
      <td>quote.USD.percent_change_90d</td>
      <td>-0.04924</td>
    </tr>
    <tr>
      <th>18</th>
      <td>BNB</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.74977</td>
    </tr>
    <tr>
      <th>19</th>
      <td>BNB</td>
      <td>quote.USD.percent_change_24h</td>
      <td>0.83082</td>
    </tr>
    <tr>
      <th>20</th>
      <td>BNB</td>
      <td>quote.USD.percent_change_7d</td>
      <td>9.05144</td>
    </tr>
    <tr>
      <th>21</th>
      <td>BNB</td>
      <td>quote.USD.percent_change_30d</td>
      <td>-3.78312</td>
    </tr>
    <tr>
      <th>22</th>
      <td>BNB</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-0.78192</td>
    </tr>
    <tr>
      <th>23</th>
      <td>BNB</td>
      <td>quote.USD.percent_change_90d</td>
      <td>5.11585</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Solana</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-1.06803</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Solana</td>
      <td>quote.USD.percent_change_24h</td>
      <td>2.37399</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Solana</td>
      <td>quote.USD.percent_change_7d</td>
      <td>12.40713</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Solana</td>
      <td>quote.USD.percent_change_30d</td>
      <td>12.02192</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Solana</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-7.85117</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Solana</td>
      <td>quote.USD.percent_change_90d</td>
      <td>18.12620</td>
    </tr>
    <tr>
      <th>30</th>
      <td>XRP</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.24694</td>
    </tr>
    <tr>
      <th>31</th>
      <td>XRP</td>
      <td>quote.USD.percent_change_24h</td>
      <td>12.04140</td>
    </tr>
    <tr>
      <th>32</th>
      <td>XRP</td>
      <td>quote.USD.percent_change_7d</td>
      <td>38.92497</td>
    </tr>
    <tr>
      <th>33</th>
      <td>XRP</td>
      <td>quote.USD.percent_change_30d</td>
      <td>23.12027</td>
    </tr>
    <tr>
      <th>34</th>
      <td>XRP</td>
      <td>quote.USD.percent_change_60d</td>
      <td>16.89664</td>
    </tr>
    <tr>
      <th>35</th>
      <td>XRP</td>
      <td>quote.USD.percent_change_90d</td>
      <td>23.36795</td>
    </tr>
    <tr>
      <th>36</th>
      <td>USDC</td>
      <td>quote.USD.percent_change_1h</td>
      <td>0.01082</td>
    </tr>
    <tr>
      <th>37</th>
      <td>USDC</td>
      <td>quote.USD.percent_change_24h</td>
      <td>-0.00264</td>
    </tr>
    <tr>
      <th>38</th>
      <td>USDC</td>
      <td>quote.USD.percent_change_7d</td>
      <td>0.00472</td>
    </tr>
    <tr>
      <th>39</th>
      <td>USDC</td>
      <td>quote.USD.percent_change_30d</td>
      <td>0.00549</td>
    </tr>
    <tr>
      <th>40</th>
      <td>USDC</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-0.00216</td>
    </tr>
    <tr>
      <th>41</th>
      <td>USDC</td>
      <td>quote.USD.percent_change_90d</td>
      <td>-0.02575</td>
    </tr>
    <tr>
      <th>42</th>
      <td>Toncoin</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.68928</td>
    </tr>
    <tr>
      <th>43</th>
      <td>Toncoin</td>
      <td>quote.USD.percent_change_24h</td>
      <td>-2.33508</td>
    </tr>
    <tr>
      <th>44</th>
      <td>Toncoin</td>
      <td>quote.USD.percent_change_7d</td>
      <td>-1.57426</td>
    </tr>
    <tr>
      <th>45</th>
      <td>Toncoin</td>
      <td>quote.USD.percent_change_30d</td>
      <td>-7.15873</td>
    </tr>
    <tr>
      <th>46</th>
      <td>Toncoin</td>
      <td>quote.USD.percent_change_60d</td>
      <td>10.91285</td>
    </tr>
    <tr>
      <th>47</th>
      <td>Toncoin</td>
      <td>quote.USD.percent_change_90d</td>
      <td>17.52035</td>
    </tr>
    <tr>
      <th>48</th>
      <td>Dogecoin</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.97964</td>
    </tr>
    <tr>
      <th>49</th>
      <td>Dogecoin</td>
      <td>quote.USD.percent_change_24h</td>
      <td>1.64740</td>
    </tr>
    <tr>
      <th>50</th>
      <td>Dogecoin</td>
      <td>quote.USD.percent_change_7d</td>
      <td>13.41039</td>
    </tr>
    <tr>
      <th>51</th>
      <td>Dogecoin</td>
      <td>quote.USD.percent_change_30d</td>
      <td>-7.50462</td>
    </tr>
    <tr>
      <th>52</th>
      <td>Dogecoin</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-20.45762</td>
    </tr>
    <tr>
      <th>53</th>
      <td>Dogecoin</td>
      <td>quote.USD.percent_change_90d</td>
      <td>-16.73450</td>
    </tr>
    <tr>
      <th>54</th>
      <td>Cardano</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.52428</td>
    </tr>
    <tr>
      <th>55</th>
      <td>Cardano</td>
      <td>quote.USD.percent_change_24h</td>
      <td>3.23046</td>
    </tr>
    <tr>
      <th>56</th>
      <td>Cardano</td>
      <td>quote.USD.percent_change_7d</td>
      <td>16.42994</td>
    </tr>
    <tr>
      <th>57</th>
      <td>Cardano</td>
      <td>quote.USD.percent_change_30d</td>
      <td>10.22147</td>
    </tr>
    <tr>
      <th>58</th>
      <td>Cardano</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-7.98226</td>
    </tr>
    <tr>
      <th>59</th>
      <td>Cardano</td>
      <td>quote.USD.percent_change_90d</td>
      <td>-1.29000</td>
    </tr>
    <tr>
      <th>60</th>
      <td>TRON</td>
      <td>quote.USD.percent_change_1h</td>
      <td>0.03135</td>
    </tr>
    <tr>
      <th>61</th>
      <td>TRON</td>
      <td>quote.USD.percent_change_24h</td>
      <td>0.38899</td>
    </tr>
    <tr>
      <th>62</th>
      <td>TRON</td>
      <td>quote.USD.percent_change_7d</td>
      <td>3.52567</td>
    </tr>
    <tr>
      <th>63</th>
      <td>TRON</td>
      <td>quote.USD.percent_change_30d</td>
      <td>15.33851</td>
    </tr>
    <tr>
      <th>64</th>
      <td>TRON</td>
      <td>quote.USD.percent_change_60d</td>
      <td>8.85538</td>
    </tr>
    <tr>
      <th>65</th>
      <td>TRON</td>
      <td>quote.USD.percent_change_90d</td>
      <td>22.78627</td>
    </tr>
    <tr>
      <th>66</th>
      <td>Shiba Inu</td>
      <td>quote.USD.percent_change_1h</td>
      <td>0.13788</td>
    </tr>
    <tr>
      <th>67</th>
      <td>Shiba Inu</td>
      <td>quote.USD.percent_change_24h</td>
      <td>0.16280</td>
    </tr>
    <tr>
      <th>68</th>
      <td>Shiba Inu</td>
      <td>quote.USD.percent_change_7d</td>
      <td>15.58935</td>
    </tr>
    <tr>
      <th>69</th>
      <td>Shiba Inu</td>
      <td>quote.USD.percent_change_30d</td>
      <td>-3.15363</td>
    </tr>
    <tr>
      <th>70</th>
      <td>Shiba Inu</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-22.93486</td>
    </tr>
    <tr>
      <th>71</th>
      <td>Shiba Inu</td>
      <td>quote.USD.percent_change_90d</td>
      <td>-13.62610</td>
    </tr>
    <tr>
      <th>72</th>
      <td>Avalanche</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-1.40468</td>
    </tr>
    <tr>
      <th>73</th>
      <td>Avalanche</td>
      <td>quote.USD.percent_change_24h</td>
      <td>3.50296</td>
    </tr>
    <tr>
      <th>74</th>
      <td>Avalanche</td>
      <td>quote.USD.percent_change_7d</td>
      <td>4.59963</td>
    </tr>
    <tr>
      <th>75</th>
      <td>Avalanche</td>
      <td>quote.USD.percent_change_30d</td>
      <td>-1.55128</td>
    </tr>
    <tr>
      <th>76</th>
      <td>Avalanche</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-24.81821</td>
    </tr>
    <tr>
      <th>77</th>
      <td>Avalanche</td>
      <td>quote.USD.percent_change_90d</td>
      <td>-19.73124</td>
    </tr>
    <tr>
      <th>78</th>
      <td>Polkadot</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.61933</td>
    </tr>
    <tr>
      <th>79</th>
      <td>Polkadot</td>
      <td>quote.USD.percent_change_24h</td>
      <td>2.63259</td>
    </tr>
    <tr>
      <th>80</th>
      <td>Polkadot</td>
      <td>quote.USD.percent_change_7d</td>
      <td>5.23403</td>
    </tr>
    <tr>
      <th>81</th>
      <td>Polkadot</td>
      <td>quote.USD.percent_change_30d</td>
      <td>4.02893</td>
    </tr>
    <tr>
      <th>82</th>
      <td>Polkadot</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-10.50497</td>
    </tr>
    <tr>
      <th>83</th>
      <td>Polkadot</td>
      <td>quote.USD.percent_change_90d</td>
      <td>-3.92834</td>
    </tr>
    <tr>
      <th>84</th>
      <td>Chainlink</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.65909</td>
    </tr>
    <tr>
      <th>85</th>
      <td>Chainlink</td>
      <td>quote.USD.percent_change_24h</td>
      <td>1.78882</td>
    </tr>
    <tr>
      <th>86</th>
      <td>Chainlink</td>
      <td>quote.USD.percent_change_7d</td>
      <td>11.01146</td>
    </tr>
    <tr>
      <th>87</th>
      <td>Chainlink</td>
      <td>quote.USD.percent_change_30d</td>
      <td>-0.03754</td>
    </tr>
    <tr>
      <th>88</th>
      <td>Chainlink</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-11.39020</td>
    </tr>
    <tr>
      <th>89</th>
      <td>Chainlink</td>
      <td>quote.USD.percent_change_90d</td>
      <td>7.21067</td>
    </tr>
  </tbody>
</table>
</div>




```python
df7 = df6.rename(columns={'level_1': 'percent_change'})
df7
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>percent_change</th>
      <th>values</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Bitcoin</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.62572</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Bitcoin</td>
      <td>quote.USD.percent_change_24h</td>
      <td>1.56736</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Bitcoin</td>
      <td>quote.USD.percent_change_7d</td>
      <td>10.62718</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Bitcoin</td>
      <td>quote.USD.percent_change_30d</td>
      <td>-1.58852</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Bitcoin</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-3.68419</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Bitcoin</td>
      <td>quote.USD.percent_change_90d</td>
      <td>3.14370</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Ethereum</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.91889</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Ethereum</td>
      <td>quote.USD.percent_change_24h</td>
      <td>0.92089</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Ethereum</td>
      <td>quote.USD.percent_change_7d</td>
      <td>11.23546</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Ethereum</td>
      <td>quote.USD.percent_change_30d</td>
      <td>-2.01435</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Ethereum</td>
      <td>quote.USD.percent_change_60d</td>
      <td>9.88936</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Ethereum</td>
      <td>quote.USD.percent_change_90d</td>
      <td>13.04704</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Tether USDt</td>
      <td>quote.USD.percent_change_1h</td>
      <td>0.00944</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Tether USDt</td>
      <td>quote.USD.percent_change_24h</td>
      <td>-0.01274</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Tether USDt</td>
      <td>quote.USD.percent_change_7d</td>
      <td>0.03935</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Tether USDt</td>
      <td>quote.USD.percent_change_30d</td>
      <td>0.10155</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Tether USDt</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-0.00421</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Tether USDt</td>
      <td>quote.USD.percent_change_90d</td>
      <td>-0.04924</td>
    </tr>
    <tr>
      <th>18</th>
      <td>BNB</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.74977</td>
    </tr>
    <tr>
      <th>19</th>
      <td>BNB</td>
      <td>quote.USD.percent_change_24h</td>
      <td>0.83082</td>
    </tr>
    <tr>
      <th>20</th>
      <td>BNB</td>
      <td>quote.USD.percent_change_7d</td>
      <td>9.05144</td>
    </tr>
    <tr>
      <th>21</th>
      <td>BNB</td>
      <td>quote.USD.percent_change_30d</td>
      <td>-3.78312</td>
    </tr>
    <tr>
      <th>22</th>
      <td>BNB</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-0.78192</td>
    </tr>
    <tr>
      <th>23</th>
      <td>BNB</td>
      <td>quote.USD.percent_change_90d</td>
      <td>5.11585</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Solana</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-1.06803</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Solana</td>
      <td>quote.USD.percent_change_24h</td>
      <td>2.37399</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Solana</td>
      <td>quote.USD.percent_change_7d</td>
      <td>12.40713</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Solana</td>
      <td>quote.USD.percent_change_30d</td>
      <td>12.02192</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Solana</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-7.85117</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Solana</td>
      <td>quote.USD.percent_change_90d</td>
      <td>18.12620</td>
    </tr>
    <tr>
      <th>30</th>
      <td>XRP</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.24694</td>
    </tr>
    <tr>
      <th>31</th>
      <td>XRP</td>
      <td>quote.USD.percent_change_24h</td>
      <td>12.04140</td>
    </tr>
    <tr>
      <th>32</th>
      <td>XRP</td>
      <td>quote.USD.percent_change_7d</td>
      <td>38.92497</td>
    </tr>
    <tr>
      <th>33</th>
      <td>XRP</td>
      <td>quote.USD.percent_change_30d</td>
      <td>23.12027</td>
    </tr>
    <tr>
      <th>34</th>
      <td>XRP</td>
      <td>quote.USD.percent_change_60d</td>
      <td>16.89664</td>
    </tr>
    <tr>
      <th>35</th>
      <td>XRP</td>
      <td>quote.USD.percent_change_90d</td>
      <td>23.36795</td>
    </tr>
    <tr>
      <th>36</th>
      <td>USDC</td>
      <td>quote.USD.percent_change_1h</td>
      <td>0.01082</td>
    </tr>
    <tr>
      <th>37</th>
      <td>USDC</td>
      <td>quote.USD.percent_change_24h</td>
      <td>-0.00264</td>
    </tr>
    <tr>
      <th>38</th>
      <td>USDC</td>
      <td>quote.USD.percent_change_7d</td>
      <td>0.00472</td>
    </tr>
    <tr>
      <th>39</th>
      <td>USDC</td>
      <td>quote.USD.percent_change_30d</td>
      <td>0.00549</td>
    </tr>
    <tr>
      <th>40</th>
      <td>USDC</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-0.00216</td>
    </tr>
    <tr>
      <th>41</th>
      <td>USDC</td>
      <td>quote.USD.percent_change_90d</td>
      <td>-0.02575</td>
    </tr>
    <tr>
      <th>42</th>
      <td>Toncoin</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.68928</td>
    </tr>
    <tr>
      <th>43</th>
      <td>Toncoin</td>
      <td>quote.USD.percent_change_24h</td>
      <td>-2.33508</td>
    </tr>
    <tr>
      <th>44</th>
      <td>Toncoin</td>
      <td>quote.USD.percent_change_7d</td>
      <td>-1.57426</td>
    </tr>
    <tr>
      <th>45</th>
      <td>Toncoin</td>
      <td>quote.USD.percent_change_30d</td>
      <td>-7.15873</td>
    </tr>
    <tr>
      <th>46</th>
      <td>Toncoin</td>
      <td>quote.USD.percent_change_60d</td>
      <td>10.91285</td>
    </tr>
    <tr>
      <th>47</th>
      <td>Toncoin</td>
      <td>quote.USD.percent_change_90d</td>
      <td>17.52035</td>
    </tr>
    <tr>
      <th>48</th>
      <td>Dogecoin</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.97964</td>
    </tr>
    <tr>
      <th>49</th>
      <td>Dogecoin</td>
      <td>quote.USD.percent_change_24h</td>
      <td>1.64740</td>
    </tr>
    <tr>
      <th>50</th>
      <td>Dogecoin</td>
      <td>quote.USD.percent_change_7d</td>
      <td>13.41039</td>
    </tr>
    <tr>
      <th>51</th>
      <td>Dogecoin</td>
      <td>quote.USD.percent_change_30d</td>
      <td>-7.50462</td>
    </tr>
    <tr>
      <th>52</th>
      <td>Dogecoin</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-20.45762</td>
    </tr>
    <tr>
      <th>53</th>
      <td>Dogecoin</td>
      <td>quote.USD.percent_change_90d</td>
      <td>-16.73450</td>
    </tr>
    <tr>
      <th>54</th>
      <td>Cardano</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.52428</td>
    </tr>
    <tr>
      <th>55</th>
      <td>Cardano</td>
      <td>quote.USD.percent_change_24h</td>
      <td>3.23046</td>
    </tr>
    <tr>
      <th>56</th>
      <td>Cardano</td>
      <td>quote.USD.percent_change_7d</td>
      <td>16.42994</td>
    </tr>
    <tr>
      <th>57</th>
      <td>Cardano</td>
      <td>quote.USD.percent_change_30d</td>
      <td>10.22147</td>
    </tr>
    <tr>
      <th>58</th>
      <td>Cardano</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-7.98226</td>
    </tr>
    <tr>
      <th>59</th>
      <td>Cardano</td>
      <td>quote.USD.percent_change_90d</td>
      <td>-1.29000</td>
    </tr>
    <tr>
      <th>60</th>
      <td>TRON</td>
      <td>quote.USD.percent_change_1h</td>
      <td>0.03135</td>
    </tr>
    <tr>
      <th>61</th>
      <td>TRON</td>
      <td>quote.USD.percent_change_24h</td>
      <td>0.38899</td>
    </tr>
    <tr>
      <th>62</th>
      <td>TRON</td>
      <td>quote.USD.percent_change_7d</td>
      <td>3.52567</td>
    </tr>
    <tr>
      <th>63</th>
      <td>TRON</td>
      <td>quote.USD.percent_change_30d</td>
      <td>15.33851</td>
    </tr>
    <tr>
      <th>64</th>
      <td>TRON</td>
      <td>quote.USD.percent_change_60d</td>
      <td>8.85538</td>
    </tr>
    <tr>
      <th>65</th>
      <td>TRON</td>
      <td>quote.USD.percent_change_90d</td>
      <td>22.78627</td>
    </tr>
    <tr>
      <th>66</th>
      <td>Shiba Inu</td>
      <td>quote.USD.percent_change_1h</td>
      <td>0.13788</td>
    </tr>
    <tr>
      <th>67</th>
      <td>Shiba Inu</td>
      <td>quote.USD.percent_change_24h</td>
      <td>0.16280</td>
    </tr>
    <tr>
      <th>68</th>
      <td>Shiba Inu</td>
      <td>quote.USD.percent_change_7d</td>
      <td>15.58935</td>
    </tr>
    <tr>
      <th>69</th>
      <td>Shiba Inu</td>
      <td>quote.USD.percent_change_30d</td>
      <td>-3.15363</td>
    </tr>
    <tr>
      <th>70</th>
      <td>Shiba Inu</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-22.93486</td>
    </tr>
    <tr>
      <th>71</th>
      <td>Shiba Inu</td>
      <td>quote.USD.percent_change_90d</td>
      <td>-13.62610</td>
    </tr>
    <tr>
      <th>72</th>
      <td>Avalanche</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-1.40468</td>
    </tr>
    <tr>
      <th>73</th>
      <td>Avalanche</td>
      <td>quote.USD.percent_change_24h</td>
      <td>3.50296</td>
    </tr>
    <tr>
      <th>74</th>
      <td>Avalanche</td>
      <td>quote.USD.percent_change_7d</td>
      <td>4.59963</td>
    </tr>
    <tr>
      <th>75</th>
      <td>Avalanche</td>
      <td>quote.USD.percent_change_30d</td>
      <td>-1.55128</td>
    </tr>
    <tr>
      <th>76</th>
      <td>Avalanche</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-24.81821</td>
    </tr>
    <tr>
      <th>77</th>
      <td>Avalanche</td>
      <td>quote.USD.percent_change_90d</td>
      <td>-19.73124</td>
    </tr>
    <tr>
      <th>78</th>
      <td>Polkadot</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.61933</td>
    </tr>
    <tr>
      <th>79</th>
      <td>Polkadot</td>
      <td>quote.USD.percent_change_24h</td>
      <td>2.63259</td>
    </tr>
    <tr>
      <th>80</th>
      <td>Polkadot</td>
      <td>quote.USD.percent_change_7d</td>
      <td>5.23403</td>
    </tr>
    <tr>
      <th>81</th>
      <td>Polkadot</td>
      <td>quote.USD.percent_change_30d</td>
      <td>4.02893</td>
    </tr>
    <tr>
      <th>82</th>
      <td>Polkadot</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-10.50497</td>
    </tr>
    <tr>
      <th>83</th>
      <td>Polkadot</td>
      <td>quote.USD.percent_change_90d</td>
      <td>-3.92834</td>
    </tr>
    <tr>
      <th>84</th>
      <td>Chainlink</td>
      <td>quote.USD.percent_change_1h</td>
      <td>-0.65909</td>
    </tr>
    <tr>
      <th>85</th>
      <td>Chainlink</td>
      <td>quote.USD.percent_change_24h</td>
      <td>1.78882</td>
    </tr>
    <tr>
      <th>86</th>
      <td>Chainlink</td>
      <td>quote.USD.percent_change_7d</td>
      <td>11.01146</td>
    </tr>
    <tr>
      <th>87</th>
      <td>Chainlink</td>
      <td>quote.USD.percent_change_30d</td>
      <td>-0.03754</td>
    </tr>
    <tr>
      <th>88</th>
      <td>Chainlink</td>
      <td>quote.USD.percent_change_60d</td>
      <td>-11.39020</td>
    </tr>
    <tr>
      <th>89</th>
      <td>Chainlink</td>
      <td>quote.USD.percent_change_90d</td>
      <td>7.21067</td>
    </tr>
  </tbody>
</table>
</div>




```python
df7['percent_change']=df7['percent_change'].replace(['quote.USD.percent_change_24h','quote.USD.percent_change_7d','quote.USD.percent_change_30d','quote.USD.percent_change_60d','quote.USD.percent_change_90d'],['24h','7d','30d','60d','90d'])
df7
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>percent_change</th>
      <th>values</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Bitcoin</td>
      <td>1h</td>
      <td>-0.62572</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Bitcoin</td>
      <td>24h</td>
      <td>1.56736</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Bitcoin</td>
      <td>7d</td>
      <td>10.62718</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Bitcoin</td>
      <td>30d</td>
      <td>-1.58852</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Bitcoin</td>
      <td>60d</td>
      <td>-3.68419</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Bitcoin</td>
      <td>90d</td>
      <td>3.14370</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Ethereum</td>
      <td>1h</td>
      <td>-0.91889</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Ethereum</td>
      <td>24h</td>
      <td>0.92089</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Ethereum</td>
      <td>7d</td>
      <td>11.23546</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Ethereum</td>
      <td>30d</td>
      <td>-2.01435</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Ethereum</td>
      <td>60d</td>
      <td>9.88936</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Ethereum</td>
      <td>90d</td>
      <td>13.04704</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Tether USDt</td>
      <td>1h</td>
      <td>0.00944</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Tether USDt</td>
      <td>24h</td>
      <td>-0.01274</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Tether USDt</td>
      <td>7d</td>
      <td>0.03935</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Tether USDt</td>
      <td>30d</td>
      <td>0.10155</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Tether USDt</td>
      <td>60d</td>
      <td>-0.00421</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Tether USDt</td>
      <td>90d</td>
      <td>-0.04924</td>
    </tr>
    <tr>
      <th>18</th>
      <td>BNB</td>
      <td>1h</td>
      <td>-0.74977</td>
    </tr>
    <tr>
      <th>19</th>
      <td>BNB</td>
      <td>24h</td>
      <td>0.83082</td>
    </tr>
    <tr>
      <th>20</th>
      <td>BNB</td>
      <td>7d</td>
      <td>9.05144</td>
    </tr>
    <tr>
      <th>21</th>
      <td>BNB</td>
      <td>30d</td>
      <td>-3.78312</td>
    </tr>
    <tr>
      <th>22</th>
      <td>BNB</td>
      <td>60d</td>
      <td>-0.78192</td>
    </tr>
    <tr>
      <th>23</th>
      <td>BNB</td>
      <td>90d</td>
      <td>5.11585</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Solana</td>
      <td>1h</td>
      <td>-1.06803</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Solana</td>
      <td>24h</td>
      <td>2.37399</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Solana</td>
      <td>7d</td>
      <td>12.40713</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Solana</td>
      <td>30d</td>
      <td>12.02192</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Solana</td>
      <td>60d</td>
      <td>-7.85117</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Solana</td>
      <td>90d</td>
      <td>18.12620</td>
    </tr>
    <tr>
      <th>30</th>
      <td>XRP</td>
      <td>1h</td>
      <td>-0.24694</td>
    </tr>
    <tr>
      <th>31</th>
      <td>XRP</td>
      <td>24h</td>
      <td>12.04140</td>
    </tr>
    <tr>
      <th>32</th>
      <td>XRP</td>
      <td>7d</td>
      <td>38.92497</td>
    </tr>
    <tr>
      <th>33</th>
      <td>XRP</td>
      <td>30d</td>
      <td>23.12027</td>
    </tr>
    <tr>
      <th>34</th>
      <td>XRP</td>
      <td>60d</td>
      <td>16.89664</td>
    </tr>
    <tr>
      <th>35</th>
      <td>XRP</td>
      <td>90d</td>
      <td>23.36795</td>
    </tr>
    <tr>
      <th>36</th>
      <td>USDC</td>
      <td>1h</td>
      <td>0.01082</td>
    </tr>
    <tr>
      <th>37</th>
      <td>USDC</td>
      <td>24h</td>
      <td>-0.00264</td>
    </tr>
    <tr>
      <th>38</th>
      <td>USDC</td>
      <td>7d</td>
      <td>0.00472</td>
    </tr>
    <tr>
      <th>39</th>
      <td>USDC</td>
      <td>30d</td>
      <td>0.00549</td>
    </tr>
    <tr>
      <th>40</th>
      <td>USDC</td>
      <td>60d</td>
      <td>-0.00216</td>
    </tr>
    <tr>
      <th>41</th>
      <td>USDC</td>
      <td>90d</td>
      <td>-0.02575</td>
    </tr>
    <tr>
      <th>42</th>
      <td>Toncoin</td>
      <td>1h</td>
      <td>-0.68928</td>
    </tr>
    <tr>
      <th>43</th>
      <td>Toncoin</td>
      <td>24h</td>
      <td>-2.33508</td>
    </tr>
    <tr>
      <th>44</th>
      <td>Toncoin</td>
      <td>7d</td>
      <td>-1.57426</td>
    </tr>
    <tr>
      <th>45</th>
      <td>Toncoin</td>
      <td>30d</td>
      <td>-7.15873</td>
    </tr>
    <tr>
      <th>46</th>
      <td>Toncoin</td>
      <td>60d</td>
      <td>10.91285</td>
    </tr>
    <tr>
      <th>47</th>
      <td>Toncoin</td>
      <td>90d</td>
      <td>17.52035</td>
    </tr>
    <tr>
      <th>48</th>
      <td>Dogecoin</td>
      <td>1h</td>
      <td>-0.97964</td>
    </tr>
    <tr>
      <th>49</th>
      <td>Dogecoin</td>
      <td>24h</td>
      <td>1.64740</td>
    </tr>
    <tr>
      <th>50</th>
      <td>Dogecoin</td>
      <td>7d</td>
      <td>13.41039</td>
    </tr>
    <tr>
      <th>51</th>
      <td>Dogecoin</td>
      <td>30d</td>
      <td>-7.50462</td>
    </tr>
    <tr>
      <th>52</th>
      <td>Dogecoin</td>
      <td>60d</td>
      <td>-20.45762</td>
    </tr>
    <tr>
      <th>53</th>
      <td>Dogecoin</td>
      <td>90d</td>
      <td>-16.73450</td>
    </tr>
    <tr>
      <th>54</th>
      <td>Cardano</td>
      <td>1h</td>
      <td>-0.52428</td>
    </tr>
    <tr>
      <th>55</th>
      <td>Cardano</td>
      <td>24h</td>
      <td>3.23046</td>
    </tr>
    <tr>
      <th>56</th>
      <td>Cardano</td>
      <td>7d</td>
      <td>16.42994</td>
    </tr>
    <tr>
      <th>57</th>
      <td>Cardano</td>
      <td>30d</td>
      <td>10.22147</td>
    </tr>
    <tr>
      <th>58</th>
      <td>Cardano</td>
      <td>60d</td>
      <td>-7.98226</td>
    </tr>
    <tr>
      <th>59</th>
      <td>Cardano</td>
      <td>90d</td>
      <td>-1.29000</td>
    </tr>
    <tr>
      <th>60</th>
      <td>TRON</td>
      <td>1h</td>
      <td>0.03135</td>
    </tr>
    <tr>
      <th>61</th>
      <td>TRON</td>
      <td>24h</td>
      <td>0.38899</td>
    </tr>
    <tr>
      <th>62</th>
      <td>TRON</td>
      <td>7d</td>
      <td>3.52567</td>
    </tr>
    <tr>
      <th>63</th>
      <td>TRON</td>
      <td>30d</td>
      <td>15.33851</td>
    </tr>
    <tr>
      <th>64</th>
      <td>TRON</td>
      <td>60d</td>
      <td>8.85538</td>
    </tr>
    <tr>
      <th>65</th>
      <td>TRON</td>
      <td>90d</td>
      <td>22.78627</td>
    </tr>
    <tr>
      <th>66</th>
      <td>Shiba Inu</td>
      <td>1h</td>
      <td>0.13788</td>
    </tr>
    <tr>
      <th>67</th>
      <td>Shiba Inu</td>
      <td>24h</td>
      <td>0.16280</td>
    </tr>
    <tr>
      <th>68</th>
      <td>Shiba Inu</td>
      <td>7d</td>
      <td>15.58935</td>
    </tr>
    <tr>
      <th>69</th>
      <td>Shiba Inu</td>
      <td>30d</td>
      <td>-3.15363</td>
    </tr>
    <tr>
      <th>70</th>
      <td>Shiba Inu</td>
      <td>60d</td>
      <td>-22.93486</td>
    </tr>
    <tr>
      <th>71</th>
      <td>Shiba Inu</td>
      <td>90d</td>
      <td>-13.62610</td>
    </tr>
    <tr>
      <th>72</th>
      <td>Avalanche</td>
      <td>1h</td>
      <td>-1.40468</td>
    </tr>
    <tr>
      <th>73</th>
      <td>Avalanche</td>
      <td>24h</td>
      <td>3.50296</td>
    </tr>
    <tr>
      <th>74</th>
      <td>Avalanche</td>
      <td>7d</td>
      <td>4.59963</td>
    </tr>
    <tr>
      <th>75</th>
      <td>Avalanche</td>
      <td>30d</td>
      <td>-1.55128</td>
    </tr>
    <tr>
      <th>76</th>
      <td>Avalanche</td>
      <td>60d</td>
      <td>-24.81821</td>
    </tr>
    <tr>
      <th>77</th>
      <td>Avalanche</td>
      <td>90d</td>
      <td>-19.73124</td>
    </tr>
    <tr>
      <th>78</th>
      <td>Polkadot</td>
      <td>1h</td>
      <td>-0.61933</td>
    </tr>
    <tr>
      <th>79</th>
      <td>Polkadot</td>
      <td>24h</td>
      <td>2.63259</td>
    </tr>
    <tr>
      <th>80</th>
      <td>Polkadot</td>
      <td>7d</td>
      <td>5.23403</td>
    </tr>
    <tr>
      <th>81</th>
      <td>Polkadot</td>
      <td>30d</td>
      <td>4.02893</td>
    </tr>
    <tr>
      <th>82</th>
      <td>Polkadot</td>
      <td>60d</td>
      <td>-10.50497</td>
    </tr>
    <tr>
      <th>83</th>
      <td>Polkadot</td>
      <td>90d</td>
      <td>-3.92834</td>
    </tr>
    <tr>
      <th>84</th>
      <td>Chainlink</td>
      <td>1h</td>
      <td>-0.65909</td>
    </tr>
    <tr>
      <th>85</th>
      <td>Chainlink</td>
      <td>24h</td>
      <td>1.78882</td>
    </tr>
    <tr>
      <th>86</th>
      <td>Chainlink</td>
      <td>7d</td>
      <td>11.01146</td>
    </tr>
    <tr>
      <th>87</th>
      <td>Chainlink</td>
      <td>30d</td>
      <td>-0.03754</td>
    </tr>
    <tr>
      <th>88</th>
      <td>Chainlink</td>
      <td>60d</td>
      <td>-11.39020</td>
    </tr>
    <tr>
      <th>89</th>
      <td>Chainlink</td>
      <td>90d</td>
      <td>7.21067</td>
    </tr>
  </tbody>
</table>
</div>




```python
import seaborn as sns
import matplotlib.pyplot as plt
```


```python
!pip install seaborn
```

    Defaulting to user installation because normal site-packages is not writeable
    Requirement already satisfied: seaborn in c:\users\dipender meena\appdata\roaming\python\python312\site-packages (0.13.2)
    Requirement already satisfied: numpy!=1.24.0,>=1.20 in c:\users\dipender meena\appdata\roaming\python\python312\site-packages (from seaborn) (2.0.0)
    Requirement already satisfied: pandas>=1.2 in c:\users\dipender meena\appdata\roaming\python\python312\site-packages (from seaborn) (2.2.2)
    Requirement already satisfied: matplotlib!=3.6.1,>=3.4 in c:\users\dipender meena\appdata\roaming\python\python312\site-packages (from seaborn) (3.9.1)
    Requirement already satisfied: contourpy>=1.0.1 in c:\users\dipender meena\appdata\roaming\python\python312\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (1.2.1)
    Requirement already satisfied: cycler>=0.10 in c:\users\dipender meena\appdata\roaming\python\python312\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (0.12.1)
    Requirement already satisfied: fonttools>=4.22.0 in c:\users\dipender meena\appdata\roaming\python\python312\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (4.53.1)
    Requirement already satisfied: kiwisolver>=1.3.1 in c:\users\dipender meena\appdata\roaming\python\python312\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (1.4.5)
    Requirement already satisfied: packaging>=20.0 in c:\users\dipender meena\appdata\roaming\python\python312\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (24.1)
    Requirement already satisfied: pillow>=8 in c:\users\dipender meena\appdata\roaming\python\python312\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (10.4.0)
    Requirement already satisfied: pyparsing>=2.3.1 in c:\users\dipender meena\appdata\roaming\python\python312\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (3.1.2)
    Requirement already satisfied: python-dateutil>=2.7 in c:\users\dipender meena\appdata\roaming\python\python312\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in c:\users\dipender meena\appdata\roaming\python\python312\site-packages (from pandas>=1.2->seaborn) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\dipender meena\appdata\roaming\python\python312\site-packages (from pandas>=1.2->seaborn) (2024.1)
    Requirement already satisfied: six>=1.5 in c:\users\dipender meena\appdata\roaming\python\python312\site-packages (from python-dateutil>=2.7->matplotlib!=3.6.1,>=3.4->seaborn) (1.16.0)
    


```python
sns.catplot(x='percent_change',y='values',hue='name',data=df7,kind='point')
```




    <seaborn.axisgrid.FacetGrid at 0x2b98da0c320>




    
![png](output_22_1.png)
    



```python

```


```python
df10=df[['name','quote.USD.price','timestamp']]
df10.query("name=='bitcoin'")
df10
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>quote.USD.price</th>
      <th>timestamp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Bitcoin</td>
      <td>64723.61057</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Ethereum</td>
      <td>3449.45831</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Tether USDt</td>
      <td>1.00031</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BNB</td>
      <td>575.62216</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Solana</td>
      <td>160.91142</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>5</th>
      <td>XRP</td>
      <td>0.61271</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>6</th>
      <td>USDC</td>
      <td>1.00006</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Toncoin</td>
      <td>7.22021</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Dogecoin</td>
      <td>0.12417</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Cardano</td>
      <td>0.44583</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>10</th>
      <td>TRON</td>
      <td>0.13466</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Shiba Inu</td>
      <td>0.00002</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Avalanche</td>
      <td>28.17395</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Polkadot</td>
      <td>6.44311</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Chainlink</td>
      <td>14.33461</td>
      <td>2024-07-17 17:26:34.741927</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.set_theme(style="darkgrid")

sns.lineplot(x='timestamp', y='quote.USD.price', data = df10)

```




    <Axes: xlabel='timestamp', ylabel='quote.USD.price'>




    
![png](output_25_1.png)
    



```python

```
